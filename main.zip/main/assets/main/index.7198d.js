window.__require = function t(e, o, n) {
function r(c, a) {
if (!o[c]) {
if (!e[c]) {
var s = c.split("/");
s = s[s.length - 1];
if (!e[s]) {
var p = "function" == typeof __require && __require;
if (!a && p) return p(s, !0);
if (i) return i(s, !0);
throw new Error("Cannot find module '" + c + "'");
}
c = s;
}
var l = o[c] = {
exports: {}
};
e[c][0].call(l.exports, function(t) {
return r(e[c][1][t] || t);
}, l, l.exports, t, e, o, n);
}
return o[c].exports;
}
for (var i = "function" == typeof __require && __require, c = 0; c < n.length; c++) r(n[c]);
return r;
}({
AutoDownloadTX: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "2845dYQIGVO0rYuMZV28ntr", "AutoDownloadTX");
var n, r = this && this.__extends || (n = function(t, e) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
})(t, e);
}, function(t, e) {
n(t, e);
function o() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype, new o());
}), i = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var c = t("../ui/BundleDownLoad"), a = t("./IconBundleMiniBauCua"), s = t("./IconBundleMiniLongHo"), p = cc._decorator, l = p.ccclass, u = (p.property, 
function(t) {
r(e, t);
function e() {
return null !== t && t.apply(this, arguments) || this;
}
e.prototype.onDownLoadByMd5NotLoadPreLoadCallBack = function() {
console.log("Preload TX");
this.node.getComponent(s.default).enabled = !0;
this.node.getComponent(a.default).enabled = !0;
};
return i([ l ], e);
}(c.default));
o.default = u;
cc._RF.pop();
}, {
"../ui/BundleDownLoad": "BundleDownLoad",
"./IconBundleMiniBauCua": "IconBundleMiniBauCua",
"./IconBundleMiniLongHo": "IconBundleMiniLongHo"
} ],
"BGUI.d": [ function(t, e) {
"use strict";
cc._RF.push(e, "1bd69oy6nNFeZCTarQyRNnY", "BGUI.d");
cc._RF.pop();
}, {} ],
BhvShake: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "6b367jbKq1JYYuAR/V3rR09", "BhvShake");
var n, r = this && this.__extends || (n = function(t, e) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
})(t, e);
}, function(t, e) {
n(t, e);
function o() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype, new o());
}), i = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var c = cc._decorator, a = c.ccclass, s = c.property, p = c.menu, l = function(t) {
r(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.movingMode = !1;
e.decayMode = !1;
e.damping = .01;
e.shakeTime = .5;
e.intensity = cc.v2(5, 5);
return e;
}
i([ s({
tooltip: "Chế độ chuyển động, chế độ di chuyển sẽ không khôi phục tọa độ của đối tượng trở lại trạng thái trước khi xảy ra rung lắc, thích hợp cho các đối tượng chuyển động"
}) ], e.prototype, "movingMode", void 0);
i([ s({
tooltip: "Chế độ phân rã, sẽ giảm dần theo cường độ của thời gian rung"
}) ], e.prototype, "decayMode", void 0);
i([ s({
visible: function() {
return !0 === this.decayMode;
},
tooltip: "Giảm chấn, tốc độ tại đó bán kính giảm dần trong quá trình rung"
}) ], e.prototype, "damping", void 0);
i([ s({
tooltip: "Thời gian rung"
}) ], e.prototype, "shakeTime", void 0);
i([ s({
tooltip: "Sự bù trừ của rung động x, y"
}) ], e.prototype, "intensity", void 0);
return i([ a, p("BGUI/Movement/Shake") ], e);
}(BGUI.BhvShake);
o.default = l;
cc._RF.pop();
}, {} ],
BhvSine: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "5d9e7c1ptlDEqdve7SZk4bY", "BhvSine");
var n, r = this && this.__extends || (n = function(t, e) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
})(t, e);
}, function(t, e) {
n(t, e);
function o() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype, new o());
}), i = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var c = cc._decorator, a = c.ccclass, s = c.property, p = c.menu, l = (Math.PI, 
Math.PI, Math.PI, function(t) {
r(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.activeAtStart = !0;
e.movement = BGUI.MOVEMENT.vertical;
e.wave = BGUI.WAVE.sine;
e.period = 4;
e.periodRandom = 0;
e.periodOffset = 0;
e.periodOffsetRandom = 0;
e.magnitude = 50;
e.magnitudeRandom = 0;
return e;
}
i([ s({
tooltip: "Được kích hoạt ở chức năng bắt đầu"
}) ], e.prototype, "activeAtStart", void 0);
i([ s({
type: cc.Enum(BGUI.MOVEMENT),
tooltip: "Loại thuộc tính nào được sử dụng cho chuyển động chu kỳ sin"
}) ], e.prototype, "movement", void 0);
i([ s({
type: cc.Enum(BGUI.WAVE),
tooltip: "Dạng Sóng"
}) ], e.prototype, "wave", void 0);
i([ s({
tooltip: ""
}) ], e.prototype, "period", void 0);
i([ s({
tooltip: "Khoảng thời gian ngẫu nhiên"
}) ], e.prototype, "periodRandom", void 0);
i([ s({
tooltip: "Chu kỳ bù đắp"
}) ], e.prototype, "periodOffset", void 0);
i([ s({
tooltip: "Giá trị bù chu kỳ Ngẫu nhiên"
}) ], e.prototype, "periodOffsetRandom", void 0);
i([ s({
tooltip: "Phạm vi dao động"
}) ], e.prototype, "magnitude", void 0);
i([ s({
tooltip: "Giá trị ngẫu nhiên của biên độ dao động"
}) ], e.prototype, "magnitudeRandom", void 0);
return i([ a, p("BGUI/Movement/Sine (Chức năng chuyển động)") ], e);
}(BGUI.BhvSine));
o.default = l;
cc._RF.pop();
}, {} ],
BundleDownLoad: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "271f8/NgIpEDYx7U0i7AOWF", "BundleDownLoad");
var n, r = this && this.__extends || (n = function(t, e) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
})(t, e);
}, function(t, e) {
n(t, e);
function o() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype, new o());
}), i = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var c = cc._decorator, a = c.ccclass, s = c.property, p = function(t) {
r(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.isDownloadLocal = !1;
e.linkUrl = "";
e.bundleName = "";
e.prefabMainNameURL = "";
e.prgLoadGame = null;
e.lbMsg = null;
e.autoDownload = !1;
e.isClicked = !1;
e.gameID = -1;
e.isDownloadBundleNotLoad = !1;
return e;
}
i([ s ], e.prototype, "isDownloadLocal", void 0);
i([ s({
visible: function() {
return this.isDownloadLocal;
}
}) ], e.prototype, "linkUrl", void 0);
i([ s({
visible: function() {
return this.isDownloadLocal;
}
}) ], e.prototype, "bundleName", void 0);
i([ s({
visible: function() {
return this.isDownloadLocal;
}
}) ], e.prototype, "prefabMainNameURL", void 0);
i([ s(cc.ProgressBar) ], e.prototype, "prgLoadGame", void 0);
i([ s(cc.Label) ], e.prototype, "lbMsg", void 0);
i([ s({
visible: function() {
return !this.isDownloadBundleNotLoad;
}
}) ], e.prototype, "autoDownload", void 0);
i([ s({
visible: function() {
return !this.isDownloadBundleNotLoad;
}
}) ], e.prototype, "isClicked", void 0);
i([ s ], e.prototype, "gameID", void 0);
i([ s({
visible: function() {
return !this.autoDownload;
}
}) ], e.prototype, "isDownloadBundleNotLoad", void 0);
return i([ a ], e);
}(BGUI.BundleDownLoad);
o.default = p;
cc._RF.pop();
}, {} ],
CommonAssetDefined: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "d6570HA0PpN+42el5D4GKmQ", "CommonAssetDefined");
var n, r = this && this.__extends || (n = function(t, e) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
})(t, e);
}, function(t, e) {
n(t, e);
function o() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype, new o());
}), i = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var c = t("./PrefabEDefined"), a = cc._decorator, s = a.ccclass, p = a.property, l = function(t) {
r(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.WAITING_LAYOUT = null;
e.BUTTON_COMMON = null;
e.FADED_BACKGROUND = null;
e.FADED_BACKGROUND_FADED = null;
e.CENTER_NOTIFICATION = null;
e.TEXT_FLY = null;
e.POPUP_COMMON = null;
e.TOOLTIP_MESSAGE = null;
e.listPrefabDefined = [];
return e;
}
i([ p(cc.Prefab) ], e.prototype, "WAITING_LAYOUT", void 0);
i([ p(cc.Prefab) ], e.prototype, "BUTTON_COMMON", void 0);
i([ p(cc.Prefab) ], e.prototype, "FADED_BACKGROUND", void 0);
i([ p(cc.Prefab) ], e.prototype, "FADED_BACKGROUND_FADED", void 0);
i([ p(cc.Prefab) ], e.prototype, "CENTER_NOTIFICATION", void 0);
i([ p(cc.Prefab) ], e.prototype, "TEXT_FLY", void 0);
i([ p(cc.Prefab) ], e.prototype, "POPUP_COMMON", void 0);
i([ p(cc.Prefab) ], e.prototype, "TOOLTIP_MESSAGE", void 0);
i([ p(c.default) ], e.prototype, "listPrefabDefined", void 0);
return i([ s ], e);
}(BGUI.CommonAssetDefined);
o.default = l;
cc._RF.pop();
}, {
"./PrefabEDefined": "PrefabEDefined"
} ],
DemoClearCacheCtrl: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "6cda78ovbBIMLeMs1Q0MJmO", "DemoClearCacheCtrl");
var n, r = this && this.__extends || (n = function(t, e) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
})(t, e);
}, function(t, e) {
n(t, e);
function o() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype, new o());
}), i = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var c = t("../../framework/ui/UIWindow"), a = cc._decorator, s = a.ccclass, p = (a.property, 
function(t) {
r(e, t);
function e() {
return null !== t && t.apply(this, arguments) || this;
}
e.prototype.onTouchBtn = function(t) {
var e = t.target.name;
BGUI.ZLog.log("=============" + e + "======================");
switch (e) {
case "btnShowVersionHotupdate":
this.showVerionHotupdate();
break;

case "btnClearHotUpdate":
this.onClearHotUpdate();
break;

case "btnClearCacheAllBundle":
this.onClearCachesBundleALL();
break;

case "btnClearCacheBundleByName":
this.onClearCacheBundleByName("lobby");
break;

case "btnShowMd5VersionBundle":
this.onShowMd5VersionAll();
}
};
e.prototype.onShowMd5VersionAll = function() {
for (var t = "", e = 0, o = Object.entries({
LOBBY: "lobby",
MINITAIXIU: "MiniTaiXiu",
MINILARVAR: "MiniLarva",
MINIPOKER: "MiniPoker",
MiniET: "MiniET",
TomCuaCa: "TomCuaCa",
SlotLienMinh: "SlotLienMinh",
SlotLongVuong: "SlotLongVuong",
SlotTayDuKy: "SlotTayDuKy",
SlotRungRam: "SlotRungRam",
GameCard: "GameCard",
BANCA: "BanCa"
}); e < o.length; e++) {
var n = o[e], r = n[0], i = n[1];
BGUI.ZLog.log(r + ": " + i);
var c = cc.sys.localStorage.getItem(BGUI.DATA_STORAGE.MD5CACHE + i), a = JSON.parse(c);
BGUI.ZLog.log(a);
t += i + ": " + a + "\n";
}
BGUI.UIPopupManager.instance.showPopup(t);
};
e.prototype.onClearCacheBundleByName = function() {
BGUI.UIPopupManager.instance.showPopup("Tạm thời chưa làm được!");
};
e.prototype.onClearCachesBundleALL = function() {
var t = cc.assetManager.cacheManager;
BGUI.ZLog.log("onClearCachesBundleALL====" + JSON.stringify(t));
cc.assetManager.cacheManager.clearCache();
};
e.prototype.onClearHotUpdate = function() {
var t = jsb.fileUtils.getWritablePath();
BGUI.ZLog.log(JSON.stringify(t));
if (!t) throw new Error("storagePath not exist");
if (!jsb.fileUtils.isDirectoryExist(t)) throw new Error("path:--\x3e" + t + "not exist");
jsb.fileUtils.removeDirectory(t);
setTimeout(function() {
cc.game.restart();
}, 100);
};
e.prototype.showVerionHotupdate = function() {
if (cc.sys.isNative) {
var t = cc.sys.localStorage.getItem("HotUpdateShowVersion_SS");
BGUI.UIPopupManager.instance.showPopup(t);
}
};
return i([ s ], e);
}(c.default));
o.default = p;
cc._RF.pop();
}, {
"../../framework/ui/UIWindow": "UIWindow"
} ],
DemoFrameWork: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "44cb6zm+YpL1ZsbgW5Wevc0", "DemoFrameWork");
var n, r = this && this.__extends || (n = function(t, e) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
})(t, e);
}, function(t, e) {
n(t, e);
function o() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype, new o());
}), i = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var c = t("./DemoClearCacheCtrl"), a = cc._decorator, s = a.ccclass, p = a.property, l = function(t) {
r(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.numOfShowCheat = 20;
e.nFrameWork = null;
e.nGameCache = null;
return e;
}
e.prototype.onLoad = function() {
BGUI.ZLog.log("=========================" + !1);
};
e.prototype.onTouchBtn = function(t) {
var e = t.target.name;
BGUI.ZLog.log("=============" + e + "======================");
switch (e) {
case "btnCheat":
if (BGUI.UIWindowManager.instance.hasWindow(c.default)) return;
if (this.numOfShowCheat <= 0) {
this.numOfShowCheat = 5;
BGUI.UIWindowManager.instance.showWindowFromPrefab(this.nFrameWork);
BGUI.UIWindowManager.instance.showWindowFromPrefab(this.nGameCache);
}
this.numOfShowCheat--;
}
};
e.versionHotupdate = 0;
i([ p(cc.Prefab) ], e.prototype, "nFrameWork", void 0);
i([ p(cc.Prefab) ], e.prototype, "nGameCache", void 0);
return i([ s ], e);
}(cc.Component);
o.default = l;
cc._RF.pop();
}, {
"./DemoClearCacheCtrl": "DemoClearCacheCtrl"
} ],
DemoListFramework: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "adb2akiHkNNyILwNvM6DKsT", "DemoListFramework");
var n, r = this && this.__extends || (n = function(t, e) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
})(t, e);
}, function(t, e) {
n(t, e);
function o() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype, new o());
}), i = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var c = t("../../framework/ui/UIWindow"), a = cc._decorator, s = a.ccclass, p = a.property, l = function(t) {
r(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.sceneDemo = null;
e._isFps = !1;
return e;
}
e.prototype.onTouchBtn = function(t) {
var e = t.target.name;
BGUI.ZLog.log("=============" + e + "======================");
switch (e) {
case "btnOnOffFPS":
this._isFps = !this._isFps;
cc.debug.setDisplayStats(this._isFps);
BGUI.UITextManager.showCenterNotification("Bạn vừa " + this._isFps + " FPS");
break;

case "btnOnoffDebug":
BGUI.ZLog.enable = !BGUI.ZLog.enable;
BGUI.UITextManager.showCenterNotification("Bạn vừa " + BGUI.ZLog.enable + " ZLOG");
break;

case "btnShowWaitting":
BGUI.UIWaitingLayout.showWaiting();
break;

case "btnShowTooltip":
var o = cc.Canvas.instance.node;
BGUI.UITooltipManager.instance.showTooltipMessage(o, "Đây là đoạn tooltip", t.target);
break;

case "btnShowDialog":
BGUI.UIPopupManager.instance.showSystemDialog("Ahihi Đồ Ngốc");
break;

case "btnShowDialogButton":
var n = [ BGUI.PopupAction.make("OK", function() {
BGUI.ZLog.log("OK POPup");
}), BGUI.PopupAction.make("CLOSE", function() {
BGUI.ZLog.log("CLOSE POPup");
}) ];
BGUI.UIPopupManager.instance.showPopup("POPUP ACTION", n, "Demooo");
break;

case "btnSoundClick":
case "btnMusicClick":
break;

case "btnNextScene":
BGUI.UIScreenManager.instance.pushScreen(this.sceneDemo);
break;

case "btnShowPrefab":
var r = BGUI.EBundle_Name.LOBBY;
BGUI.BundleManager.instance.getPrefabFromBundle("prefabs/Prefab_Accounts", r, function(t) {
BGUI.UIPopupManager.instance.showPopupFromPrefab(t);
});
}
};
i([ p(cc.Prefab) ], e.prototype, "sceneDemo", void 0);
return i([ s ], e);
}(c.default);
o.default = l;
cc._RF.pop();
}, {
"../../framework/ui/UIWindow": "UIWindow"
} ],
DropDownItem: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "0e0c1OzYPVOfpEPKQp433tu", "DropDownItem");
var n, r = this && this.__extends || (n = function(t, e) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
})(t, e);
}, function(t, e) {
n(t, e);
function o() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype, new o());
}), i = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var c = cc._decorator, a = c.ccclass, s = c.property, p = function(t) {
r(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.label = null;
e.sprite = null;
e.toggle = null;
return e;
}
i([ s(cc.Label) ], e.prototype, "label", void 0);
i([ s(cc.Sprite) ], e.prototype, "sprite", void 0);
i([ s(cc.Toggle) ], e.prototype, "toggle", void 0);
return i([ a() ], e);
}(BGUI.DropDownItem);
o.default = p;
cc._RF.pop();
}, {} ],
DropDownOptionData: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "fd5cfBXVIZC4Ks6evy9ygnF", "DropDownOptionData");
var n, r = this && this.__extends || (n = function(t, e) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
})(t, e);
}, function(t, e) {
n(t, e);
function o() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype, new o());
}), i = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var c = cc._decorator, a = c.ccclass, s = c.property, p = function(t) {
r(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.optionString = "";
e.optionSf = void 0;
return e;
}
i([ s() ], e.prototype, "optionString", void 0);
i([ s(cc.SpriteFrame) ], e.prototype, "optionSf", void 0);
return i([ a("DropDownOptionData") ], e);
}(BGUI.DropDownOptionData);
o.default = p;
cc._RF.pop();
}, {} ],
DropDown: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "4c73768DrRIEpBrhG+kF/zC", "DropDown");
var n, r = this && this.__extends || (n = function(t, e) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
})(t, e);
}, function(t, e) {
n(t, e);
function o() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype, new o());
}), i = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var c = t("./DropDownOptionData"), a = cc._decorator, s = a.ccclass, p = a.property, l = function(t) {
r(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.template = void 0;
e.labelCaption = void 0;
e.spriteCaption = void 0;
e.labelItem = void 0;
e.spriteItem = void 0;
e.optionDatas = [];
return e;
}
i([ p(cc.Node) ], e.prototype, "template", void 0);
i([ p(cc.Label) ], e.prototype, "labelCaption", void 0);
i([ p(cc.Sprite) ], e.prototype, "spriteCaption", void 0);
i([ p(cc.Label) ], e.prototype, "labelItem", void 0);
i([ p(cc.Sprite) ], e.prototype, "spriteItem", void 0);
i([ p([ c.default ]) ], e.prototype, "optionDatas", void 0);
return i([ s() ], e);
}(BGUI.DropDown);
o.default = l;
cc._RF.pop();
}, {
"./DropDownOptionData": "DropDownOptionData"
} ],
GameCoreManager: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "bf59c/u3uZHebYRjv7AEd5R", "GameCoreManager");
var n, r = this && this.__extends || (n = function(t, e) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
})(t, e);
}, function(t, e) {
n(t, e);
function o() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype, new o());
}), i = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var c = t("../localize/LanguageMgr"), a = cc._decorator, s = a.ccclass, p = a.property, l = t("vn"), u = t("mm"), f = t("en"), d = t("tl"), _ = t("cam"), h = function(t) {
r(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.nMiniGames = null;
e.nWidgetShowJackpot = null;
e.nLayerMiniGame = null;
e.gameName = "";
e.listFontCommon = null;
e.listFontLanguage = [];
return e;
}
e.prototype.onLoad = function() {
t.prototype.onLoad.call(this);
c.LanguageMgr.updateLang();
};
e.prototype.getLangByKey = function(t) {
return c.LanguageMgr.getString(t);
};
e.prototype.onAddLocalize = function(t) {
if (t.localize && 0 != Object.keys(t.localize).length) {
t.localizeKeyName;
Object.assign(l, t.localize.vn);
Object.assign(f, t.localize.en);
Object.assign(u, t.localize.mm);
Object.assign(d, t.localize.tl);
Object.assign(_, t.localize.cam);
c.LanguageMgr.updateLocalization(c.LanguageMgr.instance.getCurrentLanguage());
BGUI.ZLog.log(l);
}
};
e.prototype.testClicked = function() {
var t = c.LanguageMgr.getString("alert.title_notification"), e = [ BGUI.PopupAction.make(c.LanguageMgr.getString("alert.ok"), function() {}), BGUI.PopupAction.make(c.LanguageMgr.getString("alert.no"), null) ];
BGUI.UIPopupManager.instance.showPopupSmall("ahihihi", e, t);
};
i([ p(cc.Node) ], e.prototype, "nMiniGames", void 0);
i([ p(cc.Node) ], e.prototype, "nWidgetShowJackpot", void 0);
i([ p(cc.Node) ], e.prototype, "nLayerMiniGame", void 0);
i([ p(cc.String) ], e.prototype, "gameName", void 0);
i([ p(cc.Font) ], e.prototype, "listFontCommon", void 0);
i([ p(cc.Font) ], e.prototype, "listFontLanguage", void 0);
return i([ s ], e);
}(BGUI.GameCoreManager);
o.default = h;
cc._RF.pop();
}, {
"../localize/LanguageMgr": "LanguageMgr",
cam: "cam",
en: "en",
mm: "mm",
tl: "tl",
vn: "vn"
} ],
HotUpdateFirstGame: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "364b5rZSkJPEZly+EFRLDi/", "HotUpdateFirstGame");
var n, r = this && this.__extends || (n = function(t, e) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
})(t, e);
}, function(t, e) {
n(t, e);
function o() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype, new o());
}), i = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var c = t("../framework/localize/LanguageMgr"), a = cc._decorator, s = a.ccclass, p = a.property, l = function(t) {
r(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.listDMBK = [];
e.versionLabel = null;
e.lbMsg = null;
e.versionFirst = "1.0.0";
e.sceneMain = null;
e.prgBar = null;
e.btnAccept = null;
e.packageName = "_Default_";
e._countClearCache = 0;
e._updating = !1;
e._canRetry = !1;
e._failCount = 0;
e._storagePath = "";
e._am = null;
e.versionCompareHandle = null;
e._customManifestStr = null;
e.ERROR_NO = 0;
e.ERROR_CHECK_DOWNLOAD = 1;
e.ERROR_DOWNLOAD = 2;
e.ERROR_GETINFO = 3;
e.ERROR_LOAD_SCENE = 4;
e.ERROR_DOMAIN_ZERO = 5;
e.errorCase = e.ERROR_NO;
e.KEY_DOMAIN_INFO_BACKUP = "key_domain_info_backup";
e.idxDomain = 0;
e.config = null;
return e;
}
e.prototype.onLoad = function() {
c.LanguageMgr.updateLocalization(c.LanguageMgr.instance.getCurrentLanguage());
cc.sys.isNative && cc.sys.isMobile && jsb.device && jsb.device.setKeepScreenOn && jsb.device.setKeepScreenOn(!0);
if (cc.sys.getNetworkType() != cc.sys.NetworkType.NONE) this.onRequestConfig(this.listDMBK[this.idxDomain]); else {
this.btnAccept.node.active = !0;
this.showLog(c.LanguageMgr.getString("alert.error.connector.fail"));
}
};
e.prototype._initHotupdate = function() {
this._storagePath = (jsb.fileUtils ? jsb.fileUtils.getWritablePath() : "/") + this.packageName;
this.versionCompareHandle = function(t, e) {
var o = t.split("."), n = e.split(".");
BGUI.ZLog.log("HOT UPDATE: JS Custom Version Compare: version A is " + o + ", version B is " + n);
cc.sys.localStorage.setItem("HotUpdateShowVersion_SS", JSON.stringify(t));
cc.director.emit("HotUpdateShowVersion", t);
for (var r = 0; r < o.length; ++r) {
var i = parseInt(o[r]), c = parseInt(n[r] || 0);
if (i !== c) return i - c;
}
return n.length > o.length ? -1 : 0;
};
this._am = new jsb.AssetsManager(this._customManifestStr, this._storagePath, this.versionCompareHandle);
BGUI.ZLog.log(this._am._tempVersionPath);
this._am.setVerifyCallback(function(t, e) {
var o = jsb.fileUtils.getDataFromFile(t), n = window.md5(o) == e.md5;
if (!n) {
BGUI.ZLog.log("md5 is wrong, file:" + t);
return !0;
}
return n;
});
cc.sys.os === cc.sys.OS_ANDROID ? this._am.setMaxConcurrentTask(6) : this._am.setMaxConcurrentTask(8);
};
e.prototype._updateLabelVersion = function() {
this.versionLabel && (this.versionLabel.string = "v:" + this._am.getLocalManifest().getVersion());
};
e.prototype.runOnWeb = function() {
this.onUpdateFinish();
};
e.prototype.onDestroy = function() {
this._am && this._am.setEventCallback(null);
this._am = null;
};
e.prototype.showLog = function(t) {
this.lbMsg.string = t;
};
e.prototype.retry = function() {
if (!this._updating && this._canRetry) {
this._canRetry = !1;
BGUI.ZLog.log("Tải lại tệp lỗi...");
this.showLog(c.LanguageMgr.getString("loading.update_fail"));
this._am.downloadFailedAssets();
}
};
e.prototype.updateCallback = function(t) {
var e = !1, o = !1;
BGUI.ZLog.log("event.getEventCode() ====" + JSON.stringify(t.getEventCode()));
switch (t.getEventCode()) {
case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
BGUI.ZLog.log("Không tìm thấy tệp manifest，Skip.");
this.showLog(c.LanguageMgr.getString("loading.update_fail"));
this.errorCase = this.ERROR_DOWNLOAD;
o = !0;
break;

case jsb.EventAssetsManager.UPDATE_PROGRESSION:
var n = t.getPercent();
if (isNaN(n)) return;
var r = t.getMessage();
this.disPatchRateEvent(n, r);
this.showLog(c.LanguageMgr.getString("loading.load") + +Math.floor(100 * n) + "%");
break;

case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
BGUI.ZLog.log("Không tải xuống được manifest");
this.showLog(c.LanguageMgr.getString("loading.not_loading_manifest"));
this.errorCase = this.ERROR_DOWNLOAD;
o = !0;
break;

case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
BGUI.ZLog.log("Phiên bản mới nhất.");
this.showLog(c.LanguageMgr.getString("loading.latest_current_version"));
this.prgBar.progress = 1;
o = !0;
break;

case jsb.EventAssetsManager.UPDATE_FINISHED:
this.showLog("UPDATE FINISHED");
this.disPatchRateEvent(1);
e = !0;
break;

case jsb.EventAssetsManager.UPDATE_FAILED:
this.showLog("Cập nhật lỗi." + t.getMessage());
this._updating = !1;
this._canRetry = !0;
this._failCount++;
this.errorCase = this.ERROR_DOWNLOAD;
break;

case jsb.EventAssetsManager.ERROR_UPDATING:
BGUI.ZLog.log("Lỗi khi cập nhật: " + t.getAssetId() + ", " + t.getMessage());
this.showLog(c.LanguageMgr.getString("loading.update_fail"));
this.errorCase = this.ERROR_DOWNLOAD;
break;

case jsb.EventAssetsManager.ERROR_DECOMPRESS:
this.showLog(c.LanguageMgr.getString("loading.update_fail"));
this.errorCase = this.ERROR_DOWNLOAD;
}
if (o) {
this._am.setEventCallback(null);
this._updating = !1;
}
if (this._canRetry) {
this.showLog(c.LanguageMgr.getString("loading.check_internet"));
this.btnAccept.node.active = !0;
} else this.btnAccept.node.active = o;
if (e) {
this._am.setEventCallback(null);
var i = jsb.fileUtils.getSearchPaths(), a = this._am.getLocalManifest().getSearchPaths();
Array.prototype.unshift.apply(i, a);
cc.sys.localStorage.setItem("HotUpdateSearchPaths", JSON.stringify(i));
jsb.fileUtils.setSearchPaths(i);
BGUI.ZLog.log("path game main ==========================" + jsb.fileUtils.getWritablePath());
cc.audioEngine.stopAll();
setTimeout(function() {
cc.game.restart();
}, 100);
}
};
e.prototype.hotUpdate = function() {
if (this._am && !this._updating) {
this._am.setEventCallback(this.updateCallback.bind(this));
if (this._am.getState() === jsb.AssetsManager.State.UNINITED) {
var t = new jsb.Manifest(this._customManifestStr, this._storagePath);
this._am.loadLocalManifest(t, this._storagePath);
}
this._failCount = 0;
this._am.update();
this._updating = !0;
}
};
e.prototype.checkCallback = function(t) {
switch (t.getEventCode()) {
case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
this.showLog("ERROR NO LOCAL MANIFEST");
this.hotUpdateFinish(!0);
break;

case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
this.showLog("ERROR NO LOCAL MANIFEST");
this.hotUpdateFinish(!1);
break;

case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
this.showLog("ALREADY UP TO DATE");
this.hotUpdateFinish(!0);
break;

case jsb.EventAssetsManager.NEW_VERSION_FOUND:
this.showLog("NEW VERSION FOUND");
this._updating = !1;
this.hotUpdate();
return;

case jsb.EventAssetsManager.UPDATE_PROGRESSION:
var e = t.getPercent();
if (isNaN(e)) return;
var o = t.getMessage();
this.showLog("Loading: " + e + ", msg: " + o);
return;

default:
BGUI.ZLog.log("event.getEventCode():" + t.getEventCode());
return;
}
this._am.setEventCallback(null);
this._updating = !1;
};
e.prototype.checkUpdate = function() {
this._initHotupdate();
if (this._updating) this.showLog("UPDATING..."); else {
if (this._am.getState() === jsb.AssetsManager.State.UNINITED) {
var t = this.config.manifestUrl;
this._customManifestStr = JSON.stringify({
packageUrl: t,
remoteManifestUrl: t + "project.manifest",
remoteVersionUrl: t + "version.manifest",
version: this.versionFirst,
assets: {},
searchPaths: []
});
BGUI.ZLog.log(this._customManifestStr);
var e = new jsb.Manifest(this._customManifestStr, this._storagePath);
cc.assetManager.md5Pipe && (e = cc.assetManager.md5Pipe.transformURL(e));
this._am.loadLocalManifest(e, this._storagePath);
}
if (this._am.getLocalManifest() && this._am.getLocalManifest().isLoaded()) {
this._am.setEventCallback(this.checkCallback.bind(this));
this._am.checkUpdate();
this._updating = !0;
this.disPatchRateEvent(.01);
} else {
this.showLog(c.LanguageMgr.getString("loading.update_fail") + " , TRY AGAIN!!!");
this.errorCase = this.ERROR_CHECK_DOWNLOAD;
this.btnAccept.node.active = !0;
}
}
};
e.prototype.hotUpdateFinish = function(t) {
t ? cc.director.emit("HotUpdateFinish", t) : this.btnAccept.node.active = !0;
};
e.prototype.disPatchRateEvent = function(t, e) {
void 0 === e && (e = "");
t > 1 && (t = 1);
cc.director.emit("HotUpdateRate", t);
};
e.prototype.checkVersion = function() {
this.checkUpdate();
this.lbMsg.string = c.LanguageMgr.getString("loading.progress_loading_new");
};
e.prototype.onEnable = function() {
cc.director.on("HotUpdateFinish", this.onHotUpdateFinish, this);
cc.director.on("HotUpdateRate", this.onHotUpdateRate, this);
cc.director.on("HotUpdateShowVersion", this._updateLabelVersion, this);
};
e.prototype.onDisable = function() {
cc.director.off("HotUpdateFinish", this.onHotUpdateFinish, this);
cc.director.off("HotUpdateRate", this.onHotUpdateRate, this);
cc.director.off("HotUpdateShowVersion", this._updateLabelVersion, this);
};
e.prototype.onHotUpdateRate = function(t) {
var e = t;
e > 1 && (e = 1);
this.prgBar.progress = e;
this.lbMsg.string = c.LanguageMgr.getString("loading.load") + " :" + (100 * e).toFixed(2) + "%";
};
e.prototype.onUpdateFinish = function() {
var t = this;
this.lbMsg.string = "";
cc.director.preloadScene(this.sceneMain.name, function(e, o) {
var n = e / o;
t.lbMsg.string = c.LanguageMgr.getString("loading.load") + " :" + n.toFixed(0) + " %";
}, function(e) {
e ? cc.error(e) : t.sceneMain.name ? cc.director.loadScene(t.sceneMain.name) : cc.error("Chưa kéo scene nhé");
});
};
e.prototype.clearCache = function() {
if (this._countClearCache >= 5) {
this._countClearCache = 0;
BGUI.ZLog.log(this._countClearCache);
var t = this._storagePath;
if (!t) throw new Error("storagePath not exist");
if (!jsb.fileUtils.isDirectoryExist(t)) throw new Error("path:--\x3e" + t + "not exist");
jsb.fileUtils.removeDirectory(t);
setTimeout(function() {
cc.game.restart();
}, 100);
}
this._countClearCache++;
};
e.prototype.onHotUpdateFinish = function() {
this.onUpdateFinish();
};
e.prototype.onRequestConfig = function(t) {
var e = this;
t += "?v=" + Date.now();
BGUI.ZLog.log("onRequestConfig ===============>" + t);
var o = this;
this.showLog("Kiểm tra thông tin");
if (null != t && null != t) {
var n = cc.loader.getXMLHttpRequest();
n.onreadystatechange = function() {
if (4 === n.readyState) if (200 === n.status) {
e.config = JSON.parse(n.responseText);
BGUI.GameConfigZ.configFirstGame = e.config;
if (null == e.config) {
e.showLog(c.LanguageMgr.getString("loading.check_server"));
e.errorCase = o.ERROR_GETINFO;
e.btnAccept.node.active = !0;
return;
}
null != o.config.key && cc.sys.localStorage.setItem(e.KEY_DOMAIN_INFO_BACKUP + e.packageName, t);
if (e.config.pro.isShow) e.showLog(e.config.pro.msg); else {
e._updatePlugin();
cc.sys.isNative ? o.checkUpdate() : e.runOnWeb();
}
} else o.onTryRequest();
};
n.onerror = function() {
o.onTryRequest();
};
n.open("GET", t, !0);
n.send(null);
} else this.showLog("CHECK URL DMBK ====> " + t);
};
e.prototype._updatePlugin = function() {
BGUI.GameConfigZ.isDev = BGUI.GameConfigZ.configFirstGame.isLive;
BGUI.ZLog.enable = BGUI.GameConfigZ.configFirstGame.isLog;
BGUI.GameConfigZ.configFirstGame.isApp = !0;
cc.debug.setDisplayStats(BGUI.GameConfigZ.configFirstGame.isFps);
};
e.prototype.onTryRequest = function() {
var t = !0;
this.idxDomain++;
if (this.idxDomain >= this.listDMBK.length) {
this.showLog(c.LanguageMgr.getString("loading.update_fail"));
this.btnAccept.node.active = !0;
t = !1;
}
if (t) this.onRequestConfig(this.listDMBK[this.idxDomain]); else {
this.errorCase = this.ERROR_DOMAIN_ZERO;
this.btnAccept.node.active = !0;
this.showLog(c.LanguageMgr.getString("alert.error.connector.fail"));
}
};
e.prototype.onClickConfirm = function() {
this.btnAccept.node.active = !1;
BGUI.ZLog.log("errorCase----", this.errorCase);
switch (this.errorCase) {
case this.ERROR_CHECK_DOWNLOAD:
this.errorCase = this.ERROR_NO;
this.checkUpdate();
break;

case this.ERROR_DOWNLOAD:
this.errorCase = this.ERROR_NO;
this.retry();
break;

case this.ERROR_GETINFO:
this.errorCase = this.ERROR_NO;
this.showLog(c.LanguageMgr.getString("loading.check_server"));
this.onTryRequest();
break;

case this.ERROR_DOMAIN_ZERO:
this.showLog(c.LanguageMgr.getString("loading.check_server"));
this.idxDomain = 0;
this.onRequestConfig(this.listDMBK[this.idxDomain]);
}
};
i([ p({
type: cc.String
}) ], e.prototype, "listDMBK", void 0);
i([ p(cc.Label) ], e.prototype, "versionLabel", void 0);
i([ p(cc.Label) ], e.prototype, "lbMsg", void 0);
i([ p ], e.prototype, "versionFirst", void 0);
i([ p(cc.SceneAsset) ], e.prototype, "sceneMain", void 0);
i([ p(cc.ProgressBar) ], e.prototype, "prgBar", void 0);
i([ p(cc.Button) ], e.prototype, "btnAccept", void 0);
i([ p ], e.prototype, "packageName", void 0);
return i([ s ], e);
}(cc.Component);
o.default = l;
cc._RF.pop();
}, {
"../framework/localize/LanguageMgr": "LanguageMgr"
} ],
IconBundleChat: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "c501bDJG9xE6aCgg6wIZZdA", "IconBundleChat");
var n, r = this && this.__extends || (n = function(t, e) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
})(t, e);
}, function(t, e) {
n(t, e);
function o() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype, new o());
}), i = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var c = t("../ui/BundleDownLoad"), a = t("./IconLobby"), s = cc._decorator, p = s.ccclass, l = s.property, u = function(t) {
r(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.nLoadFirstGame = null;
return e;
}
e.prototype.onDownLoadByMd5NotLoadPreLoadCallBack = function() {
var t = this;
BGUI.BundleManager.instance.getPrefabFromBundle("Chat", "Chat", function() {
BGUI.ZLog.log("Load CHAT DONE");
t.nLoadFirstGame.enabled = !0;
});
};
i([ l(a.default) ], e.prototype, "nLoadFirstGame", void 0);
return i([ p ], e);
}(c.default);
o.default = u;
cc._RF.pop();
}, {
"../ui/BundleDownLoad": "BundleDownLoad",
"./IconLobby": "IconLobby"
} ],
IconBundleLobby: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "10845rydFpJYamXBCoraHni", "IconBundleLobby");
var n, r = this && this.__extends || (n = function(t, e) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
})(t, e);
}, function(t, e) {
n(t, e);
function o() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype, new o());
}), i = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var c = t("../ui/BundleDownLoad"), a = cc._decorator, s = a.ccclass, p = (a.property, 
function(t) {
r(e, t);
function e() {
return null !== t && t.apply(this, arguments) || this;
}
e.prototype.onFuturePrefabLoadDone = function() {};
return i([ s ], e);
}(c.default));
o.default = p;
cc._RF.pop();
}, {
"../ui/BundleDownLoad": "BundleDownLoad"
} ],
IconBundleMiniBauCua: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "0f0a4NZsr5DR7uONFcuU0KL", "IconBundleMiniBauCua");
var n, r = this && this.__extends || (n = function(t, e) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
})(t, e);
}, function(t, e) {
n(t, e);
function o() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype, new o());
}), i = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var c = t("../ui/BundleDownLoad"), a = cc._decorator, s = a.ccclass, p = (a.property, 
function(t) {
r(e, t);
function e() {
return null !== t && t.apply(this, arguments) || this;
}
e.prototype.onDownLoadByMd5NotLoadPreLoadCallBack = function() {
BGUI.ZLog.log("Load bundle ---\x3e", this.bundleName);
};
return i([ s ], e);
}(c.default));
o.default = p;
cc._RF.pop();
}, {
"../ui/BundleDownLoad": "BundleDownLoad"
} ],
IconBundleMiniLongHo: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "a5a9cVvqI5EeYv7Artdfhor", "IconBundleMiniLongHo");
var n, r = this && this.__extends || (n = function(t, e) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
})(t, e);
}, function(t, e) {
n(t, e);
function o() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype, new o());
}), i = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var c = t("../ui/BundleDownLoad"), a = cc._decorator, s = a.ccclass, p = (a.property, 
function(t) {
r(e, t);
function e() {
return null !== t && t.apply(this, arguments) || this;
}
e.prototype.onDownLoadByMd5NotLoadPreLoadCallBack = function() {
BGUI.ZLog.log("Load bundle ---\x3e", this.bundleName);
};
return i([ s ], e);
}(c.default));
o.default = p;
cc._RF.pop();
}, {
"../ui/BundleDownLoad": "BundleDownLoad"
} ],
IconLobby: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "9067dd1USxIFbP/8BtChpuG", "IconLobby");
var n, r = this && this.__extends || (n = function(t, e) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
})(t, e);
}, function(t, e) {
n(t, e);
function o() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype, new o());
}), i = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var c = t("../ui/BundleDownLoad"), a = cc._decorator, s = a.ccclass, p = (a.property, 
function(t) {
r(e, t);
function e() {
return null !== t && t.apply(this, arguments) || this;
}
e.prototype.onFuturePrefabLoadDone = function(t) {
var e = this;
cc.director.emit("DONE_DOWNLOAD_FIRST_BUNDLE");
BGUI.UIScreenManager.instance.initWithRootPrefab(t, function() {
e.scheduleOnce(function() {
e.node.removeFromParent(!0);
}, 2);
});
};
return i([ s ], e);
}(c.default));
o.default = p;
cc._RF.pop();
}, {
"../ui/BundleDownLoad": "BundleDownLoad"
} ],
LabelFontSet: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "33abcbdMrBNLrJRIwRxlur2", "LabelFontSet");
var n = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var r = cc._decorator, i = r.ccclass, c = r.property, a = cc.Enum({
VN: 0,
EN: 1,
MM: 2,
TL: 3,
CAM: 4
}), s = function() {
function t() {
this.language = a.VN;
this.fontName = null;
this.fontSize = 20;
}
t.prototype.setLang = function(t) {
this.language = t;
};
n([ c({
type: a
}) ], t.prototype, "language", void 0);
n([ c(cc.Font) ], t.prototype, "fontName", void 0);
n([ c({
type: cc.Integer
}) ], t.prototype, "fontSize", void 0);
return n([ i("LabelFontSet") ], t);
}();
o.default = s;
cc._RF.pop();
}, {} ],
LabelLocalized: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "3f121i5KA9Pwr7nSnv0oxa/", "LabelLocalized");
var n, r = this && this.__extends || (n = function(t, e) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
})(t, e);
}, function(t, e) {
n(t, e);
function o() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype, new o());
}), i = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var c = t("./LabelFontSet"), a = t("./LanguageMgr"), s = cc._decorator, p = s.ccclass, l = s.property, u = s.menu, f = s.requireComponent, d = function(t) {
r(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.isUseCCFont = !1;
e.fontSizeActive = a.LABEL_FONT_SIZE_CONFIG.NORMAL;
e.isCustomFontSize = !1;
e.textKey = "";
e.upperCaseString = !1;
e.isSystemFontUsed = !1;
e._localizedString = "";
e.lbFont = e.loadLang();
return e;
}
Object.defineProperty(e.prototype, "notify", {
get: function() {
return this._updateText();
},
enumerable: !1,
configurable: !0
});
Object.defineProperty(e.prototype, "localizedString", {
get: function() {
return a.LanguageMgr.getString(this.textKey) || "";
},
set: function(t) {
this.textKey = t;
},
enumerable: !1,
configurable: !0
});
e.prototype.loadLang = function() {
for (var t = [], e = 0; e < Object.keys(a.LANGUAGE).length; e++) {
var o = new c.default();
o.setLang(e);
t.push(o);
}
return t;
};
e.prototype.start = function() {
cc.Canvas.instance && cc.Canvas.instance.node.on(BGUI.EVENT_GAMECORE.EVENT_UPDATE_LANGUAGE_LABEL, this.updateLanguage, this);
};
e.prototype.updateLanguage = function() {
this._updateCustomFont();
this._updateText();
};
e.prototype._updateCustomFont = function() {
if (this.isUseCCFont) {
var t = a.LanguageMgr.instance.getCurrentLanguage(), e = Object.values(a.LANGUAGE).indexOf(t);
if (this.isCustomFontSize) {
this.lbFont[e].fontName && (this.node.getComponent(cc.Label).font = this.lbFont[e].fontName);
this.lbFont[e].fontSize && (this.node.getComponent(cc.Label).fontSize = this.lbFont[e].fontSize);
} else {
this.node.getComponent(cc.Label).fontSize = this.getSizeByKeyEnum(this.fontSizeActive);
if (this.fontSizeActive == a.LABEL_FONT_SIZE_CONFIG.TITLE_MENU || this.fontSizeActive == a.LABEL_FONT_SIZE_CONFIG.CONTENT_POPUP || this.fontSizeActive == a.LABEL_FONT_SIZE_CONFIG.CONTENT_MENU || this.fontSizeActive == a.LABEL_FONT_SIZE_CONFIG.NORMAL) {
this.node.getComponent(cc.Label).font = BGUI.GameCoreManager.instance.listFontCommon;
this.fontSizeActive == a.LABEL_FONT_SIZE_CONFIG.TITLE_MENU && (this.node.getComponent(cc.Label).enableBold = !0);
} else {
this.node.getComponent(cc.Label).font = BGUI.GameCoreManager.instance.listFontLanguage[e];
this._addLabelShadow();
switch (this.fontSizeActive) {
case a.LABEL_FONT_SIZE_CONFIG.TITLE_POPUP:
case a.LABEL_FONT_SIZE_CONFIG.BUTTON_POPUP:
}
}
}
}
};
e.prototype.getSizeByKeyEnum = function(t) {
var e = 20;
switch (t) {
case a.LABEL_FONT_SIZE_CONFIG.TITLE_POPUP:
e = 40;
break;

case a.LABEL_FONT_SIZE_CONFIG.CONTENT_POPUP:
e = 28;
break;

case a.LABEL_FONT_SIZE_CONFIG.BUTTON_POPUP:
e = 30;
break;

case a.LABEL_FONT_SIZE_CONFIG.TITLE_MENU:
e = 26;
break;

case a.LABEL_FONT_SIZE_CONFIG.CONTENT_MENU:
e = 20;
break;

case a.LABEL_FONT_SIZE_CONFIG.NORMAL:
e = 22;
}
return e;
};
e.prototype._addLabelShadow = function(t, e) {
void 0 === t && (t = 2);
void 0 === e && (e = -3);
var o = this.node.getComponent(cc.LabelShadow);
o || (o = this.node.addComponent(cc.LabelShadow));
o.color = cc.Color.BLACK;
o.blur = t;
o.offset.x = 0;
o.offset.y = e;
};
e.prototype._addLabelOutLine = function(t, e) {
void 0 === t && (t = cc.Color.ORANGE);
void 0 === e && (e = 2);
var o = this.node.getComponent(cc.LabelOutline);
o || (o = this.node.addComponent(cc.LabelOutline));
o.color = t;
o.width = e;
};
e.prototype.onLoad = function() {
this._updateCustomFont();
this._updateText();
};
e.prototype._updateText = function() {
BGUI.ZLog.log(this.localizedString);
this.localizedString && (this.upperCaseString ? this.node.getComponent(cc.Label).string = a.LanguageMgr.getString(this.textKey).toUpperCase() : this.node.getComponent(cc.Label).string = a.LanguageMgr.getString(this.textKey));
return this.node.getComponent(cc.Label).string;
};
i([ l ], e.prototype, "isUseCCFont", void 0);
i([ l({
type: cc.Enum(a.LABEL_FONT_SIZE_CONFIG),
visible: function() {
return !this.isCustomFontSize;
}
}) ], e.prototype, "fontSizeActive", void 0);
i([ l ], e.prototype, "isCustomFontSize", void 0);
i([ l({
multiline: !0,
tooltip: "Enter i18n key here"
}) ], e.prototype, "textKey", void 0);
i([ l ], e.prototype, "upperCaseString", void 0);
i([ l ], e.prototype, "notify", null);
i([ l({
override: !0,
tooltip: "Here shows the localized string of Text Key"
}) ], e.prototype, "_localizedString", void 0);
i([ l ], e.prototype, "localizedString", null);
i([ l({
type: c.default,
visible: function() {
return this.isCustomFontSize;
}
}) ], e.prototype, "lbFont", void 0);
return i([ p, u("BGUI/Multi Language/Label"), f(cc.Label) ], e);
}(cc.Component);
o.default = d;
cc._RF.pop();
}, {
"./LabelFontSet": "LabelFontSet",
"./LanguageMgr": "LanguageMgr"
} ],
LanguageMgr: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "a433bj2bmxMqITUnVb0d4OZ", "LanguageMgr");
var n, r = this && this.__extends || (n = function(t, e) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
})(t, e);
}, function(t, e) {
n(t, e);
function o() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype, new o());
});
Object.defineProperty(o, "__esModule", {
value: !0
});
o.LanguageMgr = o.LABEL_FONT_SIZE_CONFIG = o.LANGUAGE = o.COUNTRY = void 0;
o.COUNTRY = {
VIETNAM: "vn",
THAILAND: "tl",
ENGLAND: "en",
INDO: "id",
MALAYSIA: "my",
MYANMAR: "mm",
GOFA: "gofa",
INTERNATIONAL: "international"
};
o.LANGUAGE = {
VIETNAMESE: "vn",
ENGLISH: "en",
MYANMAR: "mm",
THAILAN: "tl",
CAMBODIA: "cam"
};
(function(t) {
t[t.TITLE_POPUP = 0] = "TITLE_POPUP";
t[t.CONTENT_POPUP = 1] = "CONTENT_POPUP";
t[t.BUTTON_POPUP = 2] = "BUTTON_POPUP";
t[t.TITLE_MENU = 3] = "TITLE_MENU";
t[t.CONTENT_MENU = 4] = "CONTENT_MENU";
t[t.NORMAL = 5] = "NORMAL";
})(o.LABEL_FONT_SIZE_CONFIG || (o.LABEL_FONT_SIZE_CONFIG = {}));
var i = new (t("polyglot"))({
phrases: t("en")
}), c = function(e) {
r(n, e);
function n() {
return null !== e && e.apply(this, arguments) || this;
}
n.init = function() {
BGUI.ZLog.log("BGUI.ClientDataKey.LANGUAGE", BGUI.ClientDataKey.LANGUAGE);
var t = BGUI.ClientData.getString(BGUI.ClientDataKey.LANGUAGE, "");
t || (t = n.instance.getCurrentLanguage());
i.replace(t);
};
n.getString = function(t, e) {
void 0 === e && (e = {});
return i.t(t, e);
};
n.updateLocalization = function(e) {
var o = t(e);
BGUI.ZLog.log("language =========" + e);
BGUI.ZLog.log("data =========" + JSON.stringify(o));
i.replace(o);
};
n.updateLang = function(t) {
void 0 === t && (t = o.COUNTRY.ENGLAND);
var e = BGUI.ClientData.getString(BGUI.ClientDataKey.LANGUAGE, "");
BGUI.ZLog.log("defaultLang ==------------------" + e);
if (!e) {
switch (t) {
case o.COUNTRY.VIETNAM:
e = o.LANGUAGE.VIETNAMESE;
break;

case o.COUNTRY.ENGLAND:
e = o.LANGUAGE.ENGLISH;
break;

case o.COUNTRY.MYANMAR:
e = o.LANGUAGE.MYANMAR;
break;

default:
e = o.LANGUAGE.ENGLISH;
}
BGUI.ClientData.setString(BGUI.ClientDataKey.LANGUAGE, e);
}
this.updateLocalization(e);
};
return n;
}(BGUI.LanguageMgr);
o.LanguageMgr = c;
cc._RF.pop();
}, {
en: "en",
polyglot: "polyglot"
} ],
LoginFeature: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "8b7d1eQq4JHxbM+cgSIxjq3", "LoginFeature");
var n, r = this && this.__extends || (n = function(t, e) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
})(t, e);
}, function(t, e) {
n(t, e);
function o() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype, new o());
}), i = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var c = cc._decorator, a = c.ccclass, s = c.property, p = function(t) {
r(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.tabIndex = 0;
e.guiType = BGUI.GUI_TYPE.POPUP;
e.featurePrefab = null;
e.isLoadFromUrl = !0;
e.featurePrefabUrl = "";
e.bundleName = "";
e.isNotLogin = !1;
return e;
}
i([ s ], e.prototype, "tabIndex", void 0);
i([ s({
type: cc.Enum(BGUI.GUI_TYPE)
}) ], e.prototype, "guiType", void 0);
i([ s({
type: cc.Prefab,
visible: function() {
return !this.isLoadFromUrl;
}
}) ], e.prototype, "featurePrefab", void 0);
i([ s ], e.prototype, "isLoadFromUrl", void 0);
i([ s({
visible: function() {
return this.isLoadFromUrl;
}
}) ], e.prototype, "featurePrefabUrl", void 0);
i([ s({
visible: function() {
return this.isLoadFromUrl;
}
}) ], e.prototype, "bundleName", void 0);
i([ s ], e.prototype, "isNotLogin", void 0);
return i([ a ], e);
}(BGUI.LoginFeature);
o.default = p;
cc._RF.pop();
}, {} ],
PrefabEDefined: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "a9c77lq3AJF+rUbcC9M4FrY", "PrefabEDefined");
var n = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var r = cc._decorator, i = r.ccclass, c = r.property, a = (cc.Enum({
VN: 0,
EN: 1,
MM: 2
}), function() {
function t() {
this.namePrefab = "";
this.prfDefined = null;
}
n([ c(cc.String) ], t.prototype, "namePrefab", void 0);
n([ c(cc.Prefab) ], t.prototype, "prfDefined", void 0);
return n([ i("PrefabEDefined") ], t);
}());
o.default = a;
cc._RF.pop();
}, {} ],
SpineAnimationSet: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "56bbdf7cCJAGqszWrJva9rh", "SpineAnimationSet");
var n = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var r = t("./LanguageMgr"), i = cc._decorator, c = i.ccclass, a = i.property, s = cc.Enum({
VN: 0,
EN: 1,
MM: 2
}), p = function() {
function t() {
this.language = s.VN;
this.skeletonData = null;
}
t.prototype.setLang = function(t) {
this.language = t;
};
t.prototype.getLang = function() {
return this.language == s.VN ? r.LANGUAGE.VIETNAMESE : this.language == s.EN ? r.LANGUAGE.ENGLISH : this.language == s.MM ? r.LANGUAGE.MYANMAR : void 0;
};
n([ a({
type: s
}) ], t.prototype, "language", void 0);
n([ a(sp.SkeletonData) ], t.prototype, "skeletonData", void 0);
return n([ c("SpineAnimationSet") ], t);
}();
o.default = p;
cc._RF.pop();
}, {
"./LanguageMgr": "LanguageMgr"
} ],
SpineLocalized: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "a1db0O/7NpCZoiFCtjY05wg", "SpineLocalized");
var n, r = this && this.__extends || (n = function(t, e) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
})(t, e);
}, function(t, e) {
n(t, e);
function o() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype, new o());
}), i = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var c = t("./LanguageMgr"), a = t("./SpineAnimationSet"), s = cc._decorator, p = s.ccclass, l = s.property, u = s.menu, f = function(t) {
r(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.isRunNew = !1;
e.isLoop = !0;
e.spineConfigs = e.loadLang();
return e;
}
e.prototype.loadLang = function() {
for (var t = [], e = 0; e < Object.keys(c.LANGUAGE).length; e++) {
var o = new a.default();
o.setLang(e);
t.push(o);
}
return t;
};
i([ l(cc.Boolean) ], e.prototype, "isRunNew", void 0);
i([ l(cc.Boolean) ], e.prototype, "isLoop", void 0);
i([ l({
type: [ a.default ],
visible: function() {
return !this.isRunNew;
}
}) ], e.prototype, "spineConfigs", void 0);
return i([ p, u("BGUI/Multi Language/Spine") ], e);
}(BGUI.SpineLocalized);
o.default = f;
cc._RF.pop();
}, {
"./LanguageMgr": "LanguageMgr",
"./SpineAnimationSet": "SpineAnimationSet"
} ],
SpriteFrameSet: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "f2e59J/03NPSZUyVWWoJOuu", "SpriteFrameSet");
var n = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var r = t("./LanguageMgr"), i = cc._decorator, c = i.ccclass, a = i.property, s = cc.Enum({
VN: 0,
EN: 1,
MM: 2,
TL: 3,
CAM: 4
}), p = function() {
function t() {
this.language = s.VN;
this.spriteFrame = null;
}
t.prototype.setLang = function(t) {
this.language = t;
};
t.prototype.getLang = function() {
return this.language == s.VN ? r.LANGUAGE.VIETNAMESE : this.language == s.EN ? r.LANGUAGE.ENGLISH : this.language == s.MM ? r.LANGUAGE.MYANMAR : this.language == s.TL ? r.LANGUAGE.THAILAN : this.language == s.CAM ? r.LANGUAGE.CAMBODIA : void 0;
};
n([ a({
type: s
}) ], t.prototype, "language", void 0);
n([ a(cc.SpriteFrame) ], t.prototype, "spriteFrame", void 0);
return n([ c("SpriteFrameSet") ], t);
}();
o.default = p;
cc._RF.pop();
}, {
"./LanguageMgr": "LanguageMgr"
} ],
SpriteLocalized: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "5289fxom5JMMZ9tY6WsMujG", "SpriteLocalized");
var n, r = this && this.__extends || (n = function(t, e) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
})(t, e);
}, function(t, e) {
n(t, e);
function o() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype, new o());
}), i = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var c = t("./LanguageMgr"), a = t("./SpriteFrameSet"), s = cc._decorator, p = s.ccclass, l = s.property, u = s.menu, f = function(t) {
r(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.spriteConfigs = e.loadLang();
return e;
}
e.prototype.loadLang = function() {
for (var t = [], e = 0; e < Object.keys(c.LANGUAGE).length; e++) {
var o = new a.default();
o.setLang(e);
t.push(o);
}
return t;
};
i([ l([ a.default ]) ], e.prototype, "spriteConfigs", void 0);
return i([ p, u("BGUI/Multi Language/Sprite") ], e);
}(BGUI.SpriteLocalized);
o.default = f;
cc._RF.pop();
}, {
"./LanguageMgr": "LanguageMgr",
"./SpriteFrameSet": "SpriteFrameSet"
} ],
UIAutoLayout: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "c6cda9lQuNPlLL7+cteSbei", "UIAutoLayout");
var n, r = this && this.__extends || (n = function(t, e) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
})(t, e);
}, function(t, e) {
n(t, e);
function o() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype, new o());
}), i = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var c = cc._decorator, a = c.ccclass, s = c.property, p = function(t) {
r(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.type = BGUI.eAutoLayoutType.Raw;
return e;
}
i([ s(cc.Enum({
type: cc.Enum(BGUI.eAutoLayoutType)
})) ], e.prototype, "type", void 0);
return i([ a ], e);
}(BGUI.UIAutoLayout);
o.default = p;
cc._RF.pop();
}, {} ],
UIButtonCommon: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "58361a529dG1LTx1JYiJ4GA", "UIButtonCommon");
var n, r = this && this.__extends || (n = function(t, e) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
})(t, e);
}, function(t, e) {
n(t, e);
function o() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype, new o());
}), i = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var c = t("../localize/LanguageMgr"), a = cc._decorator, s = a.ccclass, p = a.property, l = function(t) {
r(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.listSprite = [];
e.lbAction = null;
return e;
}
e.prototype.onLoad = function() {
var t = this.lbAction.string;
"" !== t && (t.toUpperCase() == c.LanguageMgr.getString("alert.ok").toUpperCase() ? this.node.getComponent(cc.Sprite).spriteFrame = this.listSprite[0] : t.toUpperCase() != c.LanguageMgr.getString("alert.no").toUpperCase() && t != c.LanguageMgr.getString("alert.close").toUpperCase() || (this.node.getComponent(cc.Sprite).spriteFrame = this.listSprite[1]));
};
i([ p(cc.SpriteFrame) ], e.prototype, "listSprite", void 0);
i([ p(cc.Label) ], e.prototype, "lbAction", void 0);
return i([ s ], e);
}(BGUI.UIButtonCommon);
o.default = l;
cc._RF.pop();
}, {
"../localize/LanguageMgr": "LanguageMgr"
} ],
UIDragDrop: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "b7247PMzvRJu5hX8uUdEr2+", "UIDragDrop");
var n, r = this && this.__extends || (n = function(t, e) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
})(t, e);
}, function(t, e) {
n(t, e);
function o() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype, new o());
}), i = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var c = cc._decorator, a = c.ccclass, s = c.property, p = function(t) {
r(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.dragAlwaysCenter = !0;
e.backToStartPosition = !1;
e.stickyDrag = !1;
e.propagateTouchEvent = !0;
e.dragScale = 1;
e.disableScrollViewWhileDrag = !0;
return e;
}
i([ s ], e.prototype, "dragAlwaysCenter", void 0);
i([ s ], e.prototype, "backToStartPosition", void 0);
i([ s ], e.prototype, "stickyDrag", void 0);
i([ s ], e.prototype, "propagateTouchEvent", void 0);
i([ s ], e.prototype, "dragScale", void 0);
i([ s ], e.prototype, "disableScrollViewWhileDrag", void 0);
return i([ a ], e);
}(BGUI.UIDragDrop);
o.default = p;
cc._RF.pop();
}, {} ],
UIDraggable: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "b338c6fXEFECb3+bljbGmPU", "UIDraggable");
var n, r = this && this.__extends || (n = function(t, e) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
})(t, e);
}, function(t, e) {
n(t, e);
function o() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype, new o());
}), i = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var c = cc._decorator, a = c.ccclass, s = c.property, p = function(t) {
r(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.draggable = !0;
e.backToStartPosition = !1;
e.autoFitEdge = !1;
return e;
}
i([ s ], e.prototype, "draggable", void 0);
i([ s ], e.prototype, "backToStartPosition", void 0);
i([ s ], e.prototype, "autoFitEdge", void 0);
return i([ a ], e);
}(BGUI.UIDraggable);
o.default = p;
cc._RF.pop();
}, {} ],
UIJoystick: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "1417dvOjyhG7qZIi1TJTTxC", "UIJoystick");
var n, r = this && this.__extends || (n = function(t, e) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
})(t, e);
}, function(t, e) {
n(t, e);
function o() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype, new o());
}), i = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var c = cc._decorator, a = c.ccclass, s = c.property, p = function(t) {
r(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.analog = null;
e.background = null;
e.radius = 60;
e.touchAnyWhereToStart = !0;
e.followFinger = !0;
return e;
}
i([ s(cc.Node) ], e.prototype, "analog", void 0);
i([ s(cc.Node) ], e.prototype, "background", void 0);
i([ s ], e.prototype, "radius", void 0);
i([ s ], e.prototype, "touchAnyWhereToStart", void 0);
i([ s ], e.prototype, "followFinger", void 0);
return i([ a ], e);
}(BGUI.UIJoystick);
o.default = p;
cc._RF.pop();
}, {} ],
UIPersitsNode: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "5cd3ew3VKdAh6L7xnu2XSSg", "UIPersitsNode");
var n, r = this && this.__extends || (n = function(t, e) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
})(t, e);
}, function(t, e) {
n(t, e);
function o() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype, new o());
}), i = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var c = cc._decorator, a = c.ccclass, s = (c.property, function(t) {
r(e, t);
function e() {
return null !== t && t.apply(this, arguments) || this;
}
e.prototype.onLoad = function() {
cc.game.addPersistRootNode(this.node);
};
return i([ a ], e);
}(cc.Component));
o.default = s;
cc._RF.pop();
}, {} ],
UIPopupCommon: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "f08fe9yX5BCq4keohrUs7Wh", "UIPopupCommon");
var n, r = this && this.__extends || (n = function(t, e) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
})(t, e);
}, function(t, e) {
n(t, e);
function o() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype, new o());
}), i = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var c = cc._decorator, a = c.ccclass, s = c.property, p = function(t) {
r(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.lbTitle = null;
e.lbContent = null;
e.nCustomView = null;
e.nActionContainer = null;
e.buttons = new Map();
e.nSmall = null;
e.nBig = null;
e.lbContent_Small = null;
e.nActionContainerSmall = null;
return e;
}
i([ s(cc.Label) ], e.prototype, "lbTitle", void 0);
i([ s(cc.Label) ], e.prototype, "lbContent", void 0);
i([ s(cc.Node) ], e.prototype, "nCustomView", void 0);
i([ s(cc.Node) ], e.prototype, "nActionContainer", void 0);
i([ s(cc.Node) ], e.prototype, "nSmall", void 0);
i([ s(cc.Node) ], e.prototype, "nBig", void 0);
i([ s(cc.Label) ], e.prototype, "lbContent_Small", void 0);
i([ s(cc.Node) ], e.prototype, "nActionContainerSmall", void 0);
return i([ a ], e);
}(BGUI.UIPopupCommon);
o.default = p;
cc._RF.pop();
}, {} ],
UIPopup: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "2558ehHVUhC1Y7abTC2mXc3", "UIPopup");
var n, r = this && this.__extends || (n = function(t, e) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
})(t, e);
}, function(t, e) {
n(t, e);
function o() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype, new o());
}), i = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var c = cc._decorator, a = c.ccclass, s = (c.property, function(t) {
r(e, t);
function e() {
return null !== t && t.apply(this, arguments) || this;
}
return i([ a ], e);
}(BGUI.UIPopup));
o.default = s;
cc._RF.pop();
}, {} ],
UIScreen: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "742e77TYztKOK9Af6WwIErB", "UIScreen");
var n, r = this && this.__extends || (n = function(t, e) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
})(t, e);
}, function(t, e) {
n(t, e);
function o() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype, new o());
}), i = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var c = cc._decorator, a = c.ccclass, s = c.property, p = function(t) {
r(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.hideCurScreenOnShow = !0;
return e;
}
i([ s(cc.Boolean) ], e.prototype, "hideCurScreenOnShow", void 0);
return i([ a ], e);
}(BGUI.UIScreen);
o.default = p;
cc._RF.pop();
}, {} ],
UIScrollBar: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "eb2bf77+s1LKIARwbyQpinD", "UIScrollBar");
var n, r = this && this.__extends || (n = function(t, e) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
})(t, e);
}, function(t, e) {
n(t, e);
function o() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype, new o());
}), i = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
o.UIScrollBarDirection = void 0;
var c, a = cc._decorator, s = a.ccclass, p = a.property;
(function(t) {
t[t.HORIZONTAL = 0] = "HORIZONTAL";
t[t.VERTICAL = 1] = "VERTICAL";
})(c = o.UIScrollBarDirection || (o.UIScrollBarDirection = {}));
var l = function(t) {
r(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.handle = null;
e.direction = c.VERTICAL;
e.enableAutoHide = !0;
e.autoHideTime = 1;
return e;
}
i([ p(cc.Sprite) ], e.prototype, "handle", void 0);
i([ p({
type: cc.Enum(c)
}) ], e.prototype, "direction", void 0);
i([ p(cc.Boolean) ], e.prototype, "enableAutoHide", void 0);
i([ p(cc.Float) ], e.prototype, "autoHideTime", void 0);
return i([ s ], e);
}(BGUI.UIScrollBar);
o.default = l;
cc._RF.pop();
}, {} ],
UIScrollContent: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "a2324boZkJFxpzNX6zz85gx", "UIScrollContent");
var n, r = this && this.__extends || (n = function(t, e) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
})(t, e);
}, function(t, e) {
n(t, e);
function o() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype, new o());
}), i = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var c = cc._decorator, a = c.ccclass, s = (c.property, function(t) {
r(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e._scrollView = null;
return e;
}
Object.defineProperty(e.prototype, "scrollView", {
get: function() {
return this._scrollView;
},
set: function(t) {
this._scrollView = t;
},
enumerable: !1,
configurable: !0
});
return i([ a ], e);
}(cc.Component));
o.default = s;
cc._RF.pop();
}, {} ],
UIScrollView: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "4d28aYP5v1NRJI1EFf152rw", "UIScrollView");
var n, r = this && this.__extends || (n = function(t, e) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
})(t, e);
}, function(t, e) {
n(t, e);
function o() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype, new o());
}), i = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var c = t("./UIScrollBar"), a = cc._decorator, s = a.ccclass, p = a.property, l = function(t) {
r(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.direction = BGUI.UIScrollDirection.BOTH;
e.zoomScaleEnabled = !1;
e.maxScale = 1;
e.minScale = 1;
e.content = null;
e.scrollEnabled = !0;
e.touchEnabled = !0;
e.dragChildrenEnabled = !1;
e.easingAutoScroll = !0;
e.movementFactor = .64;
e.horizontalScrollBar = null;
e.verticalScrollBar = null;
e.autoClearAutoScroll = !1;
e.autoClearAutoZoomScale = !1;
return e;
}
i([ p({
type: cc.Enum(BGUI.UIScrollDirection)
}) ], e.prototype, "direction", void 0);
i([ p ], e.prototype, "zoomScaleEnabled", void 0);
i([ p ], e.prototype, "maxScale", void 0);
i([ p ], e.prototype, "minScale", void 0);
i([ p(cc.Node) ], e.prototype, "content", void 0);
i([ p ], e.prototype, "scrollEnabled", void 0);
i([ p ], e.prototype, "touchEnabled", void 0);
i([ p ], e.prototype, "dragChildrenEnabled", void 0);
i([ p ], e.prototype, "easingAutoScroll", void 0);
i([ p ], e.prototype, "movementFactor", void 0);
i([ p(c.default) ], e.prototype, "horizontalScrollBar", void 0);
i([ p(c.default) ], e.prototype, "verticalScrollBar", void 0);
i([ p ], e.prototype, "autoClearAutoScroll", void 0);
i([ p ], e.prototype, "autoClearAutoZoomScale", void 0);
return i([ s ], e);
}(BGUI.UIScrollView);
o.default = l;
cc._RF.pop();
}, {
"./UIScrollBar": "UIScrollBar"
} ],
UITabbarController: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "f48e8Syq7FBnpz9MjThYlbS", "UITabbarController");
var n, r = this && this.__extends || (n = function(t, e) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
})(t, e);
}, function(t, e) {
n(t, e);
function o() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype, new o());
}), i = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var c = t("./UITabbarItem"), a = cc._decorator, s = a.ccclass, p = a.property, l = function(t) {
r(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.items = [];
e.content = null;
e.titleLabel = null;
e.startIndex = 0;
return e;
}
i([ p([ c.default ]) ], e.prototype, "items", void 0);
i([ p(cc.Node) ], e.prototype, "content", void 0);
i([ p(cc.Label) ], e.prototype, "titleLabel", void 0);
i([ p(cc.Integer) ], e.prototype, "startIndex", void 0);
return i([ s ], e);
}(BGUI.UITabbarController);
o.default = l;
cc._RF.pop();
}, {
"./UITabbarItem": "UITabbarItem"
} ],
UITabbarItem: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "b92a2UbPxROtq7hEHvw7+8y", "UITabbarItem");
var n, r = this && this.__extends || (n = function(t, e) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
})(t, e);
}, function(t, e) {
n(t, e);
function o() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype, new o());
}), i = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var c = cc._decorator, a = c.ccclass, s = c.property, p = function(t) {
r(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.title = "";
e.prefab = null;
e.isLoadFromUrl = !1;
e.featurePrefabUrl = "";
e.bundleName = "";
e.nodeContent = null;
e.nodeOn = null;
e.nodeOff = null;
return e;
}
i([ s(cc.String) ], e.prototype, "title", void 0);
i([ s({
type: cc.Prefab,
visible: function() {
return !this.isLoadFromUrl;
}
}) ], e.prototype, "prefab", void 0);
i([ s ], e.prototype, "isLoadFromUrl", void 0);
i([ s({
visible: function() {
return this.isLoadFromUrl;
}
}) ], e.prototype, "featurePrefabUrl", void 0);
i([ s({
visible: function() {
return this.isLoadFromUrl;
}
}) ], e.prototype, "bundleName", void 0);
i([ s(cc.Node) ], e.prototype, "nodeContent", void 0);
i([ s(cc.Node) ], e.prototype, "nodeOn", void 0);
i([ s(cc.Node) ], e.prototype, "nodeOff", void 0);
return i([ a ], e);
}(BGUI.UITabbarItem);
o.default = p;
cc._RF.pop();
}, {} ],
UITableCell: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "62daaYiRPtH+pZrGfUKRZsO", "UITableCell");
var n, r = this && this.__extends || (n = function(t, e) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
})(t, e);
}, function(t, e) {
n(t, e);
function o() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype, new o());
}), i = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var c = cc._decorator, a = c.ccclass, s = c.property, p = function(t) {
r(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.nSelected = null;
e.nDeselected = null;
e.nHighlighted = null;
e.nUnhighlighted = null;
return e;
}
i([ s(cc.Node) ], e.prototype, "nSelected", void 0);
i([ s(cc.Node) ], e.prototype, "nDeselected", void 0);
i([ s(cc.Node) ], e.prototype, "nHighlighted", void 0);
i([ s(cc.Node) ], e.prototype, "nUnhighlighted", void 0);
return i([ a ], e);
}(BGUI.UITableCell);
o.default = p;
cc._RF.pop();
}, {} ],
UITableView: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "a0e36R/pTtMt7lUY1yP/dOz", "UITableView");
var n, r = this && this.__extends || (n = function(t, e) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
})(t, e);
}, function(t, e) {
n(t, e);
function o() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype, new o());
}), i = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var c = t("./UIScrollBar"), a = cc._decorator, s = a.ccclass, p = a.property, l = function(t) {
r(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.direction = BGUI.UIScrollDirection.BOTH;
e.zoomScaleEnabled = !1;
e.maxScale = 1;
e.minScale = 1;
e.content = null;
e.scrollEnabled = !0;
e.touchEnabled = !0;
e.dragChildrenEnabled = !1;
e.easingAutoScroll = !0;
e.movementFactor = .64;
e.horizontalScrollBar = null;
e.verticalScrollBar = null;
e.autoClearAutoScroll = !1;
e.autoClearAutoZoomScale = !1;
e.fillOrder = BGUI.UITableViewFillOrder.LEFT_TO_RIGHT__TOP_TO_BOTTOM;
e.interactionMode = BGUI.UITableViewInteractionMode.NONE;
e.cellPagingEnabled = !1;
e.numberOfPagingCell = 1;
e.tableCell = null;
e.nEmpty = null;
return e;
}
i([ p({
type: cc.Enum(BGUI.UIScrollDirection)
}) ], e.prototype, "direction", void 0);
i([ p ], e.prototype, "zoomScaleEnabled", void 0);
i([ p ], e.prototype, "maxScale", void 0);
i([ p ], e.prototype, "minScale", void 0);
i([ p(cc.Node) ], e.prototype, "content", void 0);
i([ p ], e.prototype, "scrollEnabled", void 0);
i([ p ], e.prototype, "touchEnabled", void 0);
i([ p ], e.prototype, "dragChildrenEnabled", void 0);
i([ p ], e.prototype, "easingAutoScroll", void 0);
i([ p ], e.prototype, "movementFactor", void 0);
i([ p(c.default) ], e.prototype, "horizontalScrollBar", void 0);
i([ p(c.default) ], e.prototype, "verticalScrollBar", void 0);
i([ p ], e.prototype, "autoClearAutoScroll", void 0);
i([ p ], e.prototype, "autoClearAutoZoomScale", void 0);
i([ p({
type: cc.Enum(BGUI.UITableViewFillOrder)
}) ], e.prototype, "fillOrder", void 0);
i([ p({
type: cc.Enum(BGUI.UITableViewInteractionMode)
}) ], e.prototype, "interactionMode", void 0);
i([ p(cc.Boolean) ], e.prototype, "cellPagingEnabled", void 0);
i([ p(cc.Integer) ], e.prototype, "numberOfPagingCell", void 0);
i([ p(cc.Prefab) ], e.prototype, "tableCell", void 0);
i([ p(cc.Node) ], e.prototype, "nEmpty", void 0);
return i([ s ], e);
}(BGUI.UITableView);
o.default = l;
cc._RF.pop();
}, {
"./UIScrollBar": "UIScrollBar"
} ],
UITextManager: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "33835FdSiNMLbniOKoxQEKX", "UITextManager");
var n, r = this && this.__extends || (n = function(t, e) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
})(t, e);
}, function(t, e) {
n(t, e);
function o() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype, new o());
}), i = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var c = cc._decorator, a = c.ccclass, s = (c.property, function(t) {
r(e, t);
function e() {
return null !== t && t.apply(this, arguments) || this;
}
return i([ a ], e);
}(BGUI.UITextManager));
o.default = s;
cc._RF.pop();
}, {} ],
UITooltipHandler: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "a1d90/iSb9Ito7NsDnUV/fy", "UITooltipHandler");
var n, r = this && this.__extends || (n = function(t, e) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
})(t, e);
}, function(t, e) {
n(t, e);
function o() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype, new o());
}), i = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
o.TooltipHideType = void 0;
var c, a = cc._decorator, s = a.ccclass, p = a.property;
(function(t) {
t[t.OnTouchDownOnScreen = 0] = "OnTouchDownOnScreen";
t[t.OnTouchUpOrMoveFromTarget = 1] = "OnTouchUpOrMoveFromTarget";
t[t.Invalid = 2] = "Invalid";
})(c = o.TooltipHideType || (o.TooltipHideType = {}));
var l = function(t) {
r(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.followTarget = !0;
e.showAtTarget = !1;
e.hideType = c.OnTouchDownOnScreen;
e.manager = null;
return e;
}
i([ p ], e.prototype, "followTarget", void 0);
i([ p ], e.prototype, "showAtTarget", void 0);
i([ p({
type: cc.Enum(c)
}) ], e.prototype, "hideType", void 0);
return i([ s ], e);
}(BGUI.UITooltipHandler);
o.default = l;
cc._RF.pop();
}, {} ],
UITooltipListener: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "d36170HNpZJ5YQK3y54ATqX", "UITooltipListener");
var n, r = this && this.__extends || (n = function(t, e) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
})(t, e);
}, function(t, e) {
n(t, e);
function o() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype, new o());
}), i = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var c = cc._decorator, a = c.ccclass, s = c.property, p = function(t) {
r(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.message = "";
e.prefab = null;
e.target = null;
e.showType = BGUI.TooltipShowType.OnLongClick;
return e;
}
i([ s ], e.prototype, "message", void 0);
i([ s(cc.Prefab) ], e.prototype, "prefab", void 0);
i([ s(cc.Node) ], e.prototype, "target", void 0);
i([ s({
type: cc.Enum(BGUI.TooltipShowType)
}) ], e.prototype, "showType", void 0);
return i([ a ], e);
}(BGUI.UITooltipListener);
o.default = p;
cc._RF.pop();
}, {} ],
UITooltipManager: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "2ff118MmC1KSZM8CtawreW6", "UITooltipManager");
var n, r = this && this.__extends || (n = function(t, e) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
})(t, e);
}, function(t, e) {
n(t, e);
function o() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype, new o());
}), i = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var c = cc._decorator, a = c.ccclass, s = (c.property, function(t) {
r(e, t);
function e() {
return null !== t && t.apply(this, arguments) || this;
}
return i([ a ], e);
}(BGUI.UITooltipManager));
o.default = s;
cc._RF.pop();
}, {} ],
UITooltipMessage: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "bd03bTob9tOAYQmoYOj377n", "UITooltipMessage");
var n, r = this && this.__extends || (n = function(t, e) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
})(t, e);
}, function(t, e) {
n(t, e);
function o() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype, new o());
}), i = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var c = t("./UITooltipHandler"), a = cc._decorator, s = a.ccclass, p = a.property, l = function(t) {
r(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.spBubble = null;
e.lbMessage = null;
return e;
}
i([ p(cc.Sprite) ], e.prototype, "spBubble", void 0);
i([ p(cc.Label) ], e.prototype, "lbMessage", void 0);
return i([ s ], e);
}(c.default);
o.default = l;
cc._RF.pop();
}, {
"./UITooltipHandler": "UITooltipHandler"
} ],
UITouchHandler: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "22b49OMdi9K87wllJuw5ca+", "UITouchHandler");
var n, r = this && this.__extends || (n = function(t, e) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
})(t, e);
}, function(t, e) {
n(t, e);
function o() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype, new o());
}), i = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var c = cc._decorator, a = c.ccclass, s = c.property, p = function(t) {
r(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.touchEvent = new cc.Component.EventHandler();
e.longClickEnabled = !1;
return e;
}
i([ s(cc.Component.EventHandler) ], e.prototype, "touchEvent", void 0);
i([ s ], e.prototype, "longClickEnabled", void 0);
return i([ a ], e);
}(BGUI.UITouchHandler);
o.default = p;
cc._RF.pop();
}, {} ],
UIWaitingLayout: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "eadffzSZzdO+KkgOXSaKZBe", "UIWaitingLayout");
var n, r = this && this.__extends || (n = function(t, e) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
})(t, e);
}, function(t, e) {
n(t, e);
function o() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype, new o());
}), i = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var c = cc._decorator, a = c.ccclass, s = c.property, p = function(t) {
r(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.nFaded = null;
e.nLoading = null;
return e;
}
e.prototype.onDisable = function() {
this.node.off(cc.Node.EventType.TOUCH_START, this._onTouchStart, this);
};
e.prototype.onEnable = function() {
this.node.on(cc.Node.EventType.TOUCH_START, this._onTouchStart, this);
this.nLoading && (this.nLoading.active = !1);
this.nFaded && (this.nFaded.active = !1);
var t = cc.sequence(cc.delayTime(0), cc.callFunc(this._showWaitingUI.bind(this)));
t.setTag(99);
this.node.stopActionByTag(99);
this.node.runAction(t);
};
e.prototype._showWaitingUI = function() {
this.nLoading && (this.nLoading.active = !0);
this.nFaded && (this.nFaded.active = !0);
};
e.prototype._onTouchStart = function(t) {
t.stopPropagation();
};
i([ s(cc.Node) ], e.prototype, "nFaded", void 0);
i([ s(cc.Node) ], e.prototype, "nLoading", void 0);
return i([ a ], e);
}(BGUI.UIWaitingLayout);
o.default = p;
cc._RF.pop();
}, {} ],
UIWindow: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "5b513z6C69Kr4wF3siWJHY2", "UIWindow");
var n, r = this && this.__extends || (n = function(t, e) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
})(t, e);
}, function(t, e) {
n(t, e);
function o() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype, new o());
}), i = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var c = cc._decorator, a = c.ccclass, s = (c.property, function(t) {
r(e, t);
function e() {
return null !== t && t.apply(this, arguments) || this;
}
return i([ a ], e);
}(BGUI.UIWindow));
o.default = s;
cc._RF.pop();
}, {} ],
cam: [ function(t, e) {
"use strict";
cc._RF.push(e, "56f46Y2P3xGcr8524KB0y9d", "cam");
e.exports = {
"": "",
alert: {
title_notification: "သတိပေးစာ",
ok: "အတည်ပြုပါ",
yes: "ရှိသည်",
no: "ခွင့်မပြု",
loaded: "တာဝန်ခံ",
close: "ပယ္ဖ်က္မည္",
refuse: "ငြင်းပယ်သည်",
veritify: "တိကျမှန်ကန်မှု",
fail: "မှားယွင်းချက်",
discard: "ပြန်လည်ရွေးချယ်ပါ",
confirm_logout: "မင်းထွက်ချင်တာသေချာလား?",
you_need_veritify_pin: "သင်၏ PIN နံပါတ် တိကျမှန်ကန်မှု လိုအပ်သည်",
you_need_veritify_phone_number: "သင်၏ ဖုန်းနံပါ်တ် တိကျမှန်ကန်မှု လိုအပ်သည်!",
you_need_veritify_loaded_card: "သင်၏ ကဒ်နံပါတ်လိုအပ်သည်",
coming_soon: "လုပ်ငန်းဖြစ်အံ့ဆဲဆဲ",
coming_soon_game: "Game မကြာမှီလာမည်",
game_maintian: "Game ပြုပြင်ဆဲ",
fucntion_maintian: "အချက်အလက်များ ပြုပြင်ထိန်းသိမ်းထားသည်",
error: {
not_enough_gold: "GOLD ေကြွ စေ့ မလုံ လောက်ပါ",
wrong_captcha: "Captcha မှားနေသည်",
wrong_syntax: "ဝါကျဖွဲ့ပုံဖွဲ့နည်းမှားနေသည်",
wrong_pin: "PIN နံပါတ် မဟုတ်ပါ , ကုဒ်နံပါတ်မှတ်ပုံတင်ထားခြင်း မရှိသေးပါ",
wrong_pin_or_not_reg_pin: "PIN နံပါတ် မှားနေသည် , ကုဒ်နံပါတ်မှတ်ပုံတင်ထားခြင်း မရှိသေးပါ",
account_undefined: "ကစားသမား မတည်ရှိပါ",
connector: {
fail: "အင်တာနက် ချိတ်ဆက်မထားပါ , ချိတ်ဆက်မှုကို ပြန်လည် စစ်ဆေးပါ",
a_2: "ကွန်ယက် ချိတ်ဆက်မှု ရှိရန် လိုအပ်သည်",
a_3: "စနစ်သို့ ဆက်သွယ်နေသည်",
a_4: "သင် လက်ဆောင်မရရှိသေးပါ.\n \n လက်ဆောင်များရရှိရန် အဖွဲ့ တစ်ခုသို့ ၀င်ရောက်ပါ!",
a_5: "‌ေကျးဇူးပြု၍ PIN ကုဒ် နံပါတ် ၀င်ရောက်ပါ",
a_6: "‌ေကျးဇူးပြု၍ Captcha ၀င်ရောက်ပါ!",
expired: "အ‌ကော့င်ထဲသို့လုပ်ငန်းဆောင်ရွက်မှုကုန်ဆုံးသွားသည် , ‌ေကျးဇူးပြု၍ ထပ်မံ၀င်ရောက်ပါ",
ban: "သင့်၏ Account (အကော့င်) ဖြစ်ပျက်နေသောသော့ခတ် (လော့ဂ်စ် / သော့ခတ်) ကသွားခဲ့သည်",
a_9: "စနစ်သို့ ပြုပြင်နေသည် \n ‌ေကျးဇူးပြု၍နောက်မှ ပြန်လာပါရန်!",
some_where: "The account is already logged in elsewhere"
},
services: {
a_10: "သုံးစွဲသူ၏ စာရင်း (သို့မဟုတ်) လျို့၀ှက်နံပါတ် မှားယွင်းနေပါသည်",
a_11: "Account (စာရင်း) သည် အသုံးပြုပြီး ဖြစ်သည်",
a_12: "Account (စာရင်း) သည် မတည်ရှိသေးပါ",
a_13: "လျို့၀ှက်နံပါတ် မှားယွင်းနေပါသည်",
a_14: "သင်သည် အလွန်များပြားသော Account (စာရင်း ) များ မှတ်ပုံတင် ထားသည်.",
a_15: "သင်၏ Account (စာရင်း) ဖန်တီးနေခြင်းကို ဆက်လက်ရန် ေကျးဇူးပြု၍ မိနစ် အနည်းငယ်စော့င်ပါ.",
a_16: "သင်သည် အလွန်များပြားသော Account (စာရင်း ) များ ဖန်တီး ထားသည် \n  ေကျးဇူးပြု၍ မနက်ဖြန်မှ ပြန်လာပါရန်."
},
defined: {
fail: "မသိနိုငိသော ချို့ယွင်းချက်",
param_invalid: "အချက်အလက်ကမမှန်ကန်ပါ",
maintain_system: "စနစ်သို့ ပြုပြင်နေသည် , ‌ေကျးဇူးပြု၍နောက်မှ ပြန်လာပါရန်",
session_key_invalid: "Session key မတည်ရှိပါဘူး",
session_expired: "Session key ကုန်သွားပြီ",
session_room_not_exist: "ကစားကွင်းမရှိပါ",
session_not_enough_min_buy_in: "အနည်းဆုံးအလောင်းအစားမလုံလောက်ပါ",
out_buy_in_range: "အကွာအဝေးထဲက",
game_structure_invalid: "Game structure မတည်ရှိပါဘူး",
already_in_game: "သင်ဂိမ်းထဲမှာရှိနေပြီးဖြစ်သည်",
entering_game: "ဂိမ်းထဲဝင်ပါ",
gift_code_invalid: "Giftcode မတည်ရှိပါဘူး",
gift_code_is_used: "Giftcode အသုံးပြုခဲ့သည်",
gift_code_is_expired: "Giftcode ခေတ်ကုန်ပြီ",
login_banned_ip: "င့် IP သည်သော့ခတ်ထားသည်.\n ကျေးဇူးပြုပြီးဆက်သွယ်ပါ ",
login_banned_user: "သင့်အကောင့်ကိုသော့ခတ်ထားသည်.\n ကျေးဇူးပြုပြီးဆက်သွယ်ပါ ",
player_action_invalid: "မမှန်ကန်သောစစ်ဆင်ရေ",
player_action_fail: "ကြိုးကိုင်ခြယ်လှယ်မှုအမှား",
not_enough_gold: "မလုံလောက်  GOLD",
default: "အမှား",
not_bet_too_long: "သင့်အနေဖြင့်ကြာရှည်စွာမဆက်ဆံခြင်းအားဖြင့်သင့်စနစ်မှဖိတ်ကြားခြင်းခံရသည်"
}
}
},
loading: {
check_server: "Checking server information",
update: "Update",
update_success: "Update successful",
update_fail: "Update failed",
please_wait_update_version: "Please update to the latest version",
check_version: "Checking version",
progress_loading_new: "Updating the new version.",
not_loading_manifest: "Could not load manifest",
latest_current_version: "Latest current version",
load: "Loading"
}
};
cc._RF.pop();
}, {} ],
en: [ function(t, e) {
"use strict";
cc._RF.push(e, "f5810uH+rpFoKmwuMENExH7", "en");
e.exports = {
"": "",
alert: {
title_notification: "Notification",
ok: "OK",
yes: "Yes",
no: "No",
loaded: "CHARGE",
close: "Cancel",
refuse: "REJECT",
veritify: "Verify",
fail: "Error",
discard: "Reselect",
confirm_logout: "Are you sure you want to log out??",
you_need_veritify_pin: "You need to verify your PIN",
you_need_veritify_phone_number: "You need to verify your phone number!",
you_need_veritify_loaded_card: "You need to charge!",
coming_soon: "New feature is coming soon",
coming_soon_game: "Game is coming soon",
game_maintian: "The game is under maintenance now!",
fucntion_maintian: "The feature is under maintenance now!",
error: {
not_enough_gold: "InsufficientGOLD",
wrong_captcha: "Incorrect captcha",
wrong_syntax: "Incorrect syntax",
wrong_pin: "Your PIN is invalid, or your PIN is unregistered",
wrong_pin_or_not_reg_pin: "Your PIN is invalid, or your PIN is unregistered",
account_undefined: "Invalid user",
connector: {
fail: "No Internet connection\n Please check your connection again!",
a_2: "Internet required!!!",
a_3: "Connecting to system",
a_4: "You don't have gifts.\n \n Join Event to get your gifts!",
a_5: "Please enter the PIN",
a_6: "Please enter the Captcha!",
expired: "Your login session has expired, please login again",
ban: "This account has been locked by the system",
a_9: "The system is under maintenance\nPlease come back later!",
some_where: "The account is already logged in elsewhere"
},
services: {
a_10: "The account or password is incorrect",
a_11: "Account already in use",
a_12: "Account does not exist",
a_13: "Wrong password",
a_14: "You have registered too many accounts.",
a_15: "Please wait a few minutes then create your account.",
a_16: "You have created too many accounts \n please come back tomorrow."
},
defined: {
fail: "Unknown error",
param_invalid: "Parameter is incorrect",
maintain_system: "The system is under maintenance\nPlease come back later!",
session_key_invalid: "Session key does not exist",
session_expired: "Session key expired",
session_room_not_exist: "Playroom does not exist",
session_not_enough_min_buy_in: "Not enough minimum bet",
out_buy_in_range: "Out of bet",
game_structure_invalid: "Game structure does not exist",
already_in_game: "You are already in the game",
entering_game: "Entering the game",
gift_code_invalid: "Giftcode does not exist",
gift_code_is_used: "Giftcode has been used",
gift_code_is_expired: "Giftcode expired",
login_banned_ip: "Your IP has been locked. \n Please contact Customer Service for more information!",
login_banned_user: "Your account has been locked. \n Please contact Customer Service for more information!",
player_action_invalid: "Operation not valid",
player_action_fail: "Error manipulation",
not_enough_gold: "Not enough GOLD",
default: "Error",
not_bet_too_long: "You have been invited to the system  n for not interacting for too long"
}
}
},
loading: {
check_server: "Checking server information",
update: "Update",
update_success: "Update successful",
update_fail: "Update failed",
please_wait_update_version: "Please update to the latest version",
check_version: "Checking version",
progress_loading_new: "Updating the new version.",
not_loading_manifest: "Could not load manifest",
latest_current_version: "Latest current version",
load: "Loading"
},
login: {
title_quick_play: "Play now",
login: {
title: "Login",
placeholder: {
username: "Enter account name",
pass: "Enter password"
},
save_pass: "Save password",
forget: "forget",
error: {
login_fail: "Facebook login failed!",
please_enter_account_pass: "Please enter your account and password",
account_pass_than_six_charater: "Account and password must be more than 6 characters"
}
},
registry: {
title: "Register",
placeholder: {
username: "Enter account name",
pass: "Enter password",
pass_confirm: "Confirm password",
captcha: "Enter captcha"
},
error: {
facebook_fail: "Login fail",
fail_1: "The username must be at least 6 characters \n without special symbols",
fail_2: "Password must be at least 8 characters",
fail_3: "Retype password incorrect",
fail_4: "The captcha wasn't entered"
}
},
forget: {
title: "Forgot password",
placeholder: {
username: "Enter account name",
pin: "Enter PIN",
pass: "Enter password",
pass_confirm: "Confirm password",
captcha: "Enter captcha"
},
error: {
username_please: "Please enter your username",
enter_code_pin_please: "Please enter the PIN",
enter_new_password_please: "Please enter a new password",
note_create_new_password: "New password must be more than 8 characters",
wrong_enter_password: "Retype password incorrect",
enter_captcha_please: "Please enter the Captcha!",
note_create_new_password_success: "Password was successfully changed",
wrong_syntax: "Incorrect Syntax",
error_invalid_account_pin: "Username does not exist or the PIN is incorrect",
wrong_captcha: "Incorrect captcha"
}
},
safetybox: {
safetybox_title: "SAFETY BOX",
lb_goldin: "Gold in box",
lb_btn: {
chuyen: "TRANSFER",
rut: "WITHDRAW",
doimk: "CHANGE PASS",
dongy: "ACCEPT",
back: "BACK"
},
lb_editbox: {
lb_chuyen: "Number Gold Transfer",
lb_rut: "Number Gold withdraw",
placeholder_password_rut: "Type password safety box to withdraw",
placeholder_password_create: "Create password",
placeholder_re_password_create: "Re-type password",
placeholder_password_old: "Old password",
placeholder_new_password_update: "New password",
placeholder_re_new_password_update: "Re-type new password"
},
message: {}
}
}
};
cc._RF.pop();
}, {} ],
mm: [ function(t, e) {
"use strict";
cc._RF.push(e, "2d3b6Srw0hF4JkZD8oWdhD/", "mm");
e.exports = {
"": "",
alert: {
title_notification: "သတိပေးစာ",
ok: "အတည်ပြုပါ",
yes: "ရှိသည်",
no: "ခွင့်မပြု",
loaded: "တာဝန်ခံ",
close: "ပယ္ဖ်က္မည္",
refuse: "ငြင်းပယ်သည်",
veritify: "တိကျမှန်ကန်မှု",
fail: "မှားယွင်းချက်",
discard: "ပြန်လည်ရွေးချယ်ပါ",
confirm_logout: "မင်းထွက်ချင်တာသေချာလား?",
you_need_veritify_pin: "သင်၏ PIN နံပါတ် တိကျမှန်ကန်မှု လိုအပ်သည်",
you_need_veritify_phone_number: "သင်၏ ဖုန်းနံပါ်တ် တိကျမှန်ကန်မှု လိုအပ်သည်!",
you_need_veritify_loaded_card: "သင်၏ ကဒ်နံပါတ်လိုအပ်သည်",
coming_soon: "လုပ်ငန်းဖြစ်အံ့ဆဲဆဲ",
coming_soon_game: "Game မကြာမှီလာမည်",
game_maintian: "Game ပြုပြင်ဆဲ",
fucntion_maintian: "အချက်အလက်များ ပြုပြင်ထိန်းသိမ်းထားသည်",
error: {
not_enough_gold: "GOLD ေကြွ စေ့ မလုံ လောက်ပါ",
wrong_captcha: "Captcha မှားနေသည်",
wrong_syntax: "ဝါကျဖွဲ့ပုံဖွဲ့နည်းမှားနေသည်",
wrong_pin: "PIN နံပါတ် မဟုတ်ပါ , ကုဒ်နံပါတ်မှတ်ပုံတင်ထားခြင်း မရှိသေးပါ",
wrong_pin_or_not_reg_pin: "PIN နံပါတ် မှားနေသည် , ကုဒ်နံပါတ်မှတ်ပုံတင်ထားခြင်း မရှိသေးပါ",
account_undefined: "ကစားသမား မတည်ရှိပါ",
connector: {
fail: "အင်တာနက် ချိတ်ဆက်မထားပါ , ချိတ်ဆက်မှုကို ပြန်လည် စစ်ဆေးပါ",
a_2: "ကွန်ယက် ချိတ်ဆက်မှု ရှိရန် လိုအပ်သည်",
a_3: "စနစ်သို့ ဆက်သွယ်နေသည်",
a_4: "သင် လက်ဆောင်မရရှိသေးပါ.\n \n လက်ဆောင်များရရှိရန် အဖွဲ့ တစ်ခုသို့ ၀င်ရောက်ပါ!",
a_5: "‌ေကျးဇူးပြု၍ PIN ကုဒ် နံပါတ် ၀င်ရောက်ပါ",
a_6: "‌ေကျးဇူးပြု၍ Captcha ၀င်ရောက်ပါ!",
expired: "အ‌ကော့င်ထဲသို့လုပ်ငန်းဆောင်ရွက်မှုကုန်ဆုံးသွားသည် , ‌ေကျးဇူးပြု၍ ထပ်မံ၀င်ရောက်ပါ",
ban: "သင့်၏ Account (အကော့င်) ဖြစ်ပျက်နေသောသော့ခတ် (လော့ဂ်စ် / သော့ခတ်) ကသွားခဲ့သည်",
a_9: "စနစ်သို့ ပြုပြင်နေသည် \n ‌ေကျးဇူးပြု၍နောက်မှ ပြန်လာပါရန်!",
some_where: "The account is already logged in elsewhere"
},
services: {
a_10: "သုံးစွဲသူ၏ စာရင်း (သို့မဟုတ်) လျို့၀ှက်နံပါတ် မှားယွင်းနေပါသည်",
a_11: "Account (စာရင်း) သည် အသုံးပြုပြီး ဖြစ်သည်",
a_12: "Account (စာရင်း) သည် မတည်ရှိသေးပါ",
a_13: "လျို့၀ှက်နံပါတ် မှားယွင်းနေပါသည်",
a_14: "သင်သည် အလွန်များပြားသော Account (စာရင်း ) များ မှတ်ပုံတင် ထားသည်.",
a_15: "သင်၏ Account (စာရင်း) ဖန်တီးနေခြင်းကို ဆက်လက်ရန် ေကျးဇူးပြု၍ မိနစ် အနည်းငယ်စော့င်ပါ.",
a_16: "သင်သည် အလွန်များပြားသော Account (စာရင်း ) များ ဖန်တီး ထားသည် \n  ေကျးဇူးပြု၍ မနက်ဖြန်မှ ပြန်လာပါရန်."
},
defined: {
fail: "မသိနိုငိသော ချို့ယွင်းချက်",
param_invalid: "အချက်အလက်ကမမှန်ကန်ပါ",
maintain_system: "စနစ်သို့ ပြုပြင်နေသည် , ‌ေကျးဇူးပြု၍နောက်မှ ပြန်လာပါရန်",
session_key_invalid: "Session key မတည်ရှိပါဘူး",
session_expired: "Session key ကုန်သွားပြီ",
session_room_not_exist: "ကစားကွင်းမရှိပါ",
session_not_enough_min_buy_in: "အနည်းဆုံးအလောင်းအစားမလုံလောက်ပါ",
out_buy_in_range: "အကွာအဝေးထဲက",
game_structure_invalid: "Game structure မတည်ရှိပါဘူး",
already_in_game: "သင်ဂိမ်းထဲမှာရှိနေပြီးဖြစ်သည်",
entering_game: "ဂိမ်းထဲဝင်ပါ",
gift_code_invalid: "Giftcode မတည်ရှိပါဘူး",
gift_code_is_used: "Giftcode အသုံးပြုခဲ့သည်",
gift_code_is_expired: "Giftcode ခေတ်ကုန်ပြီ",
login_banned_ip: "င့် IP သည်သော့ခတ်ထားသည်.\n ကျေးဇူးပြုပြီးဆက်သွယ်ပါ ",
login_banned_user: "သင့်အကောင့်ကိုသော့ခတ်ထားသည်.\n ကျေးဇူးပြုပြီးဆက်သွယ်ပါ ",
player_action_invalid: "မမှန်ကန်သောစစ်ဆင်ရေ",
player_action_fail: "ကြိုးကိုင်ခြယ်လှယ်မှုအမှား",
not_enough_gold: "မလုံလောက်  GOLD",
default: "အမှား",
not_bet_too_long: "သင့်အနေဖြင့်ကြာရှည်စွာမဆက်ဆံခြင်းအားဖြင့်သင့်စနစ်မှဖိတ်ကြားခြင်းခံရသည်"
}
}
},
loading: {
check_server: "Checking server information",
update: "Update",
update_success: "Update successful",
update_fail: "Update failed",
please_wait_update_version: "Please update to the latest version",
check_version: "Checking version",
progress_loading_new: "Updating the new version.",
not_loading_manifest: "Could not load manifest",
latest_current_version: "Latest current version",
load: "Loading"
},
login: {
title_quick_play: "ယခုကစားမည္",
login: {
title: "အေကာင့္ဝင္မည္",
placeholder: {
username: "Account Name (စာရင်းနာမည်ဖြ့င်) ၀င်ရောက်ပါ",
pass: "လျို့၀ှက်နံပါတ် ၀င်ရောက်ပါ"
},
save_pass: "အေကာင့္ကို သိမ္းမည္။",
forget: "မေ့ နေသည်",
error: {
login_fail: "Facebook အကော့င်၀င်ရောက်ရန် ကျရှုံးသည်",
please_enter_account_pass: "ေကျးဇူးပြု၍ သင်၏ Account (စာရင်း) နှ့င် Password (လျို့၀ှက်နံပါတ်) ၀င်ရောက်ပါ",
account_pass_than_six_charater: "Account (စာရင်း) သည် ပြီးဆုံးခဲ့ သည့် အချိန် ၆ ပတ်ထက် အနည်းငယ် ရှိမှု ဖြစ်ရမည်"
}
},
registry: {
title: "မွတ္ပံုတင္ပါ",
placeholder: {
username: "Account Name (စာရင်းနာမည်ဖြ့င်) ၀င်ရောက်ပါ",
pass: " လျို့၀ှက်နံပါတ် ၀င်ရောက်ပါ",
pass_confirm: "လျို့၀ှက်နံပါတ် အတည်ပြုပါ",
captcha: "Captcha တင်သွင်းပါ"
},
error: {
facebook_fail: "Login fail",
fail_1: "Username (သုံးစွဲသူ၏နာမည်) သည် အနည်းဆုံး ၆ လုံး ဖြစ်မှ မှတ်ပုံတင်၍ ရမည် , အထူးသီးသ့န် စာလုံးများ မရှိရပါ",
fail_2: "လျို့၀ှက်နံပါတ်သည် အနည်းဆုံး စာလုံး ၈လုံး ရှိရမည်",
fail_3: "လျို့၀ှက်နံပါတ် မှားယွင်းစွာ ၀င်ရောက်နေသည်",
fail_4: "သင်၏ Captcha သို့ ၀င်ရောက်မှု မရှိသေးပါ"
}
},
forget: {
title: "လျို့၀ှက်နံပါတ်  မေ့နေသည်",
placeholder: {
username: "Account Name (စာရင်းနာမည်ဖြ့င်) ၀င်ရောက်ပါ",
pin: "PIN ကုဒ်နံပါတ်် ထည့်ပါ",
pass: " လျို့၀ှက်နံပါတ် ၀င်ရောက်ပါ",
pass_confirm: "လျို့၀ှက်နံပါတ် အတည်ပြုပါ",
captcha: "Captcha တင်သွင်းပါ"
},
error: {
username_please: "ေကျးဇူးပြု၍ သင်၏ Username (သုံးစွဲသူ၏နာမည်) ၀င်ရောက်ပါ",
enter_code_pin_please: "‌ေကျးဇူးပြု၍ PIN ကုဒ် နံပါတ် ၀င်ရောက်ပါ",
enter_new_password_please: "ေကျးဇူးပြု၍ သင်၏ New Password (လျို့၀ှက်နံပါတ်အသစ်) ၀င်ရောက်ပါ",
note_create_new_password: "လျို့၀ှက်နံပါတ်အသစ်သည် စာလုံး ၈ လုံး အထက် ဖြစ်ရမည်",
wrong_enter_password: "လျို့၀ှက်နံပါတ် မှားယွင်းစွာ ၀င်ရောက်နေသည်",
enter_captcha_please: "‌ေကျးဇူးပြု၍  Captcha ၀င်ရောက်ပါ",
note_create_new_password_success: "Password was successfully changed",
wrong_syntax: "Incorrect Syntax",
error_invalid_account_pin: "Username does not exist or the PIN is incorrect",
wrong_captcha: "Incorrect captcha"
}
}
}
};
cc._RF.pop();
}, {} ],
polyglot: [ function(t, e, o) {
(function(t) {
"use strict";
cc._RF.push(e, "7ae8fgp2ZROFqI2ZcqYAXkY", "polyglot");
(function(t, n) {
"function" == typeof define && define.amd ? define([], function() {
return n(t);
}) : "object" == typeof o ? e.exports = n(t) : t.Polyglot = n(t);
})("undefined" != typeof t ? t : void 0, function(t) {
var e = String.prototype.replace;
function o(t) {
t = t || {};
this.phrases = {};
this.extend(t.phrases || {});
this.currentLocale = t.locale || "en";
this.allowMissing = !!t.allowMissing;
this.warn = t.warn || _;
}
o.VERSION = "1.0.0";
o.prototype.locale = function(t) {
t && (this.currentLocale = t);
return this.currentLocale;
};
o.prototype.extend = function(t, e) {
var o;
for (var n in t) if (t.hasOwnProperty(n)) {
o = t[n];
e && (n = e + "." + n);
"object" == typeof o ? this.extend(o, n) : this.phrases[n] = o;
}
};
o.prototype.unset = function(t, e) {
var o;
if ("string" == typeof t) delete this.phrases[t]; else for (var n in t) if (t.hasOwnProperty(n)) {
o = t[n];
e && (n = e + "." + n);
"object" == typeof o ? this.unset(o, n) : delete this.phrases[n];
}
};
o.prototype.clear = function() {
this.phrases = {};
};
o.prototype.replace = function(t) {
this.clear();
this.extend(t);
};
o.prototype.t = function(t, e) {
var o, n;
"number" == typeof (e = null == e ? {} : e) && (e = {
smart_count: e
});
if ("string" == typeof this.phrases[t]) o = this.phrases[t]; else if ("string" == typeof e._) o = e._; else if (this.allowMissing) o = t; else {
this.warn('Missing translation for key: "' + t + '"');
n = t;
}
if ("string" == typeof o) {
e = h(e);
n = d(n = s(o, this.currentLocale, e.smart_count), e);
}
return n;
};
o.prototype.has = function(t) {
return t in this.phrases;
};
var n = "||||", r = {
chinese: function() {
return 0;
},
german: function(t) {
return 1 !== t ? 1 : 0;
},
french: function(t) {
return t > 1 ? 1 : 0;
},
russian: function(t) {
return t % 10 == 1 && t % 100 != 11 ? 0 : t % 10 >= 2 && t % 10 <= 4 && (t % 100 < 10 || t % 100 >= 20) ? 1 : 2;
},
czech: function(t) {
return 1 === t ? 0 : t >= 2 && t <= 4 ? 1 : 2;
},
polish: function(t) {
return 1 === t ? 0 : t % 10 >= 2 && t % 10 <= 4 && (t % 100 < 10 || t % 100 >= 20) ? 1 : 2;
},
icelandic: function(t) {
return t % 10 != 1 || t % 100 == 11 ? 1 : 0;
}
}, i = {
chinese: [ "fa", "id", "ja", "ko", "lo", "ms", "th", "tr", "zh" ],
german: [ "da", "de", "en", "es", "fi", "el", "he", "hu", "it", "nl", "no", "pt", "sv" ],
french: [ "fr", "tl", "pt-br" ],
russian: [ "hr", "ru" ],
czech: [ "cs", "sk" ],
polish: [ "pl" ],
icelandic: [ "is" ]
};
function c(t) {
var e, o, n, r = {};
for (e in t) if (t.hasOwnProperty(e)) {
o = t[e];
for (n in o) r[o[n]] = e;
}
return r;
}
var a = /^\s+|\s+$/g;
function s(t, o, r) {
var i, c;
return null != r && t ? (c = (i = t.split(n))[l(o, r)] || i[0], e.call(c, a, "")) : t;
}
function p(t) {
var e = c(i);
return e[t] || e.en;
}
function l(t, e) {
return r[p(t)](e);
}
var u = /\$/g, f = "$$$$";
function d(t, o) {
for (var n in o) if ("_" !== n && o.hasOwnProperty(n)) {
var r = o[n];
"string" == typeof r && (r = e.call(o[n], u, f));
t = e.call(t, new RegExp("%\\{" + n + "\\}", "g"), r);
}
return t;
}
function _(e) {
t.console && t.console.warn && t.console.warn("WARNING: " + e);
}
function h(t) {
var e = {};
for (var o in t) e[o] = t[o];
return e;
}
return o;
});
cc._RF.pop();
}).call(this, "undefined" != typeof global ? global : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
}, {} ],
tl: [ function(t, e) {
"use strict";
cc._RF.push(e, "6a468GgaKdJq4uSTGRmnxDV", "tl");
e.exports = {
alert: {
title_notification: "การแจ้งเตือน",
ok: "ยอมรับ",
yes: "ใช่",
no: "ไม่",
loaded: "เติม",
close: "ยกเลิก",
refuse: "ปฏิเสธ",
veritify: "ยึนยัน",
fail: "เกิดข้อผิดพลาด",
discard: "เลือกใหม่",
confirm_logout: "คุณแน่ใจว่าคุณต้องการที่จะออกจากระบบ?",
you_need_veritify_pin: "คุณต้องมีการยืนยัน PIN",
you_need_veritify_phone_number: "คุณต้องยืนยันหมายเลขโทรศัพท์ของคุณ!",
you_need_veritify_loaded_card: "คุณต้องเติมเงิน!",
coming_soon: "พบกับฟังก์ชั่นเร็วๆนี้",
coming_soon_game: "พบกับเกมเร็วๆนี้",
game_maintian: "เกมอยู่ระหว่างการปรับปรุง!",
fucntion_maintian: "ฟังก์ชันยู่ระหว่างการปรับปรุง!",
error: {
not_enough_gold: "เหรียญไม่พอXU",
wrong_captcha: "โค้ด Captcha ผิด",
wrong_syntax: "ไวยากรณ์ผิด",
wrong_pin: "PIN ไม่ถูกต้อง หรือยังไม่ได้ลงทะเบียน PIN",
wrong_pin_or_not_reg_pin: "PIN ผิดหรือไม่ได้ลงทะเบียนรหัส PIN",
account_undefined: "ผู้เล่นไม่มีอยู่",
connector: {
fail: "ไม่มีการเชื่อมต่ออินเทอร์เน็ต . ตรวจสอบการเชื่อมต่อของคุณอีกครั้ง!",
a_2: "ต้องต่อเน็ต!!!",
a_3: "การเชื่อมต่อกับระบบ",
a_4: "คุณยังไม่มีของขวัญ . . เข้าร่วมกิจกรรมเพื่อรับของขวัญ!",
a_5: "กรุณาป้อน PIN",
a_6: "กรุณาป้อน Captcha!",
expired: "การเข้าสู่ระบบหมดอายุ กรุณาเข้าสู่ระบบใหม่อีกครั้ง",
ban: "บัญชีนี้ถูกล็อคโดยระบบ",
a_9: "ระบบกำลังปรับปรุง โปรดกลับมาใหม่!",
some_where: "บัญชีถูกเข้าสู่ระบบที่อื่นแล้ว"
},
services: {
a_10: "บัญชีหรือรหัสผ่านไม่ถูกต้อง",
a_11: "บัญชีถูกใช้งานแล้ว",
a_12: "ไม่มีบัญชี",
a_13: "รหัสผ่านผิด",
a_14: "คุณลงทะเบียนบัญชีมากเกินไป.",
a_15: "โปรดรอสักครู่เพื่อสร้างบัญชีต่อ.",
a_16: "คุณสร้างบัญชีมากเกินไป โปรดกลับมาพรุ่งนี้"
},
defined: {
fail: "ข้อผิดพลาดที่ไม่รู้จัก",
param_invalid: "พารามิเตอร์ไม่ถูกต้อง",
maintain_system: "ระบบกำลังปรับปรุง",
session_key_invalid: "ไม่มีคีย์เซสชัน",
session_expired: "รหัสเซสชันหมดอายุ",
session_room_not_exist: "ไม่มีห้องเล่น",
session_not_enough_min_buy_in: "เดิมพันขั้นต่ำไม่พอ",
out_buy_in_range: "นอกระบบเดิมพัน",
game_structure_invalid: "ไม่มีโครงสร้างเกม",
already_in_game: "คุณอยู่ในเกมแล้ว",
entering_game: "เข้าเกม",
gift_code_invalid: "ไม่มีรหัสของขวัญ",
gift_code_is_used: "ใช้รหัสของขวัญไปแล้ว",
gift_code_is_expired: "รหัสของขวัญหมดอายุ",
login_banned_ip: "IP ของคุณถูกล็อค . กรุณาติดต่อฝ่ายบริการลูกค้าสำหรับรายละเอียดเพิ่มเติม!",
login_banned_user: "บัญชีของคุณถูกล็อค. . กรุณาติดต่อฝ่ายบริการลูกค้าสำหรับรายละเอียดเพิ่มเติม!",
player_action_invalid: "การดำเนินการไม่ถูกต้อง",
player_action_fail: "การดำเนินการผิดพลาด",
not_enough_gold: "เหรียญไม่พอXU",
default: "ข้อผิดพลาด",
not_bet_too_long: "คุณได้รับเชิญออกจากระบบเนื่องจากไม่ได้โต้ตอบนานเกินไป"
}
}
},
loading: {
check_internet: "การเชื่อมต่อไม่เสถียร ตกลงที่จะดาวน์โหลดใหม่หรือลบและติดตั้งใหม่",
check_server: "ตรวจสอบข้อมูลเซิร์ฟเวอร์",
update: "อัพเกรด",
update_success: "อัพเดทสำเร็จ",
update_fail: "การอัพเดทล้มเหลว",
please_wait_update_version: "โปรดอัปเดตเป็นเวอร์ชันล่าสุด",
check_version: "ตรวจสอบเวอร์ชัน",
progress_loading_new: "กำลังอัปเดตเวอร์ชั่นใหม่",
not_loading_manifest: "ไม่สามารถโหลด manifest",
latest_current_version: "เวอร์ชันปัจจุบันคือเวอร์ชันล่าสุด",
load: "กำลังโหลด"
}
};
cc._RF.pop();
}, {} ],
vn: [ function(t, e) {
"use strict";
cc._RF.push(e, "7dfffRjtXBHlbf42oe4MzcZ", "vn");
e.exports = {
"": "",
alert: {
title_notification: "Thông báo",
ok: "ĐỒNG Ý",
yes: "Có",
no: "KHÔNG",
loaded: "NẠP",
close: "HỦY",
refuse: "TỪ CHỐI",
veritify: "Xác thực",
fail: "Lỗi",
discard: "Chọn lại",
confirm_logout: "Bạn chắn chắn muốn đăng xuất không?",
you_need_veritify_pin: "Bạn cần xác thực mã PIN",
you_need_veritify_phone_number: "Bạn cần xác thực số điện thoại!",
you_need_veritify_loaded_card: "Bạn cần nạp thẻ!",
coming_soon: "Chức năng sắp ra mắt",
coming_soon_game: "Game sắp ra mắt!",
game_maintian: "Game đang bảo trì!",
fucntion_maintian: "Chức năng đang bảo trì!",
error: {
not_enough_gold: "Không đủ XU",
wrong_captcha: "Sai mã captcha",
wrong_syntax: "Sai cú pháp",
wrong_pin: "Mã PIN không đúng, hoặc chưa đăng ký mã PIN",
wrong_pin_or_not_reg_pin: "Sai mã PIN hoặc chưa đăng ký mã PIN",
account_undefined: "Người chơi không tồn tại",
connector: {
fail: "Không có kết nối Internet\n Kiểm tra lại kết nối của bạn!",
a_2: "Bạn cần có kết nối mạng!!!",
a_3: "Đang kết nối đến hệ thống",
a_4: "Bạn chưa có quà.\n \n Hãy tham gia Event để nhận quà!",
a_5: "Vui lòng nhập mã PIN",
a_6: "Vui lòng nhập Captcha!",
expired: "Phiên đăng nhập đã hết hạn, mời bạn đăng nhập lại",
ban: "Tài khoản này đã bị khóa bởi hệ thống",
a_9: "Hệ thống đang bảo trì\nXin vui lòng quay lại sau!",
some_where: "The account is already logged in elsewhere"
},
services: {
a_10: "Tài khoản hoặc mật khẩu không đúng",
a_11: "Tài khoản đã được sử dụng",
a_12: "Tài khoản không tồn tại",
a_13: "Sai mật khẩu",
a_14: "Bạn đã đăng kí quá nhiều tài khoản.",
a_15: "Vui lòng chờ ít phút để tiếp tục tạo tài khoản.",
a_16: "Bạn đã tạo quá nhiều tài khoản \n vui lòng quay lại vào ngày mai."
},
defined: {
fail: "Lỗi không xác định",
param_invalid: "Tham số không chính xác",
maintain_system: "Hệ thống đang bảo trì",
session_key_invalid: "Session key ko tồn tại",
session_expired: "Session key hết hạn",
session_room_not_exist: "Phòng chơi không tồn tại",
session_not_enough_min_buy_in: "Không đủ mức cược tối thiểu",
out_buy_in_range: "Ngoài mức cược",
game_structure_invalid: "Game structure không tồn tại",
already_in_game: "Bạn đã trong game",
entering_game: "Đang vào game",
gift_code_invalid: "Giftcode không tồn tại",
gift_code_is_used: "Giftcode đã được sử dụng",
gift_code_is_expired: "Giftcode đã hêt hạn",
login_banned_ip: "IP của bạn đã bị khoá.\n Vui liên hệ CSKH để biết thêm thông tin chi tiết!",
login_banned_user: "Tài khoản của bạn đã bị khoá.\n Vui liên hệ CSKH để biết thêm thông tin chi tiết!",
player_action_invalid: "Thao tác không hợp lệ",
player_action_fail: "Thao tác lỗi",
not_enough_gold: "Không đủ  XU",
default: "Lỗi",
not_bet_too_long: "Bạn bị mời ra khỏi hệ thống\ndo không tương tác quá lâu"
}
}
},
loading: {
check_server: "Checking server information",
update: "Update",
update_success: "Update successful",
update_fail: "Update failed",
please_wait_update_version: "Please update to the latest version",
check_version: "Checking version",
progress_loading_new: "Updating the new version.",
not_loading_manifest: "Could not load manifest",
latest_current_version: "Latest current version",
load: "Loading"
}
};
cc._RF.pop();
}, {} ],
zSetOrientation: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "ac57cv1zsxJLaTroV16WTil", "zSetOrientation");
var n, r = this && this.__extends || (n = function(t, e) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
})(t, e);
}, function(t, e) {
n(t, e);
function o() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype, new o());
}), i = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var c = cc._decorator, a = c.ccclass, s = c.property, p = function(t) {
r(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.isVerticle = !1;
e.sizePortrait = new cc.Size(720, 1280);
e.sizeLanscape = new cc.Size(1280, 720);
return e;
}
e.prototype.onLoad = function() {
if (!cc.sys.isBrowser) {
BGUI.ZLog.log("cc.sys.os =====: " + cc.sys.os);
BGUI.ZLog.log("isVerticle =====: " + this.isVerticle);
cc.sys.os == cc.sys.OS_IOS ? this.isVerticle ? this.callbackV() : this.callbackH() : this.isVerticle ? this.callbackAndroidVerticle() : this.callbackAndroidHorital();
}
};
e.prototype.callbackH = function() {
if (cc.sys.os == cc.sys.OS_IOS) {
jsb.reflection.callStaticMethod("AppController", "setOrientation:", "H");
var t = cc.view.getFrameSize();
BGUI.ZLog.log("frameSize: " + t.width + "   " + t.height);
cc.view.setOrientation(cc.macro.ORIENTATION_LANDSCAPE);
t.width > t.height && cc.view.setFrameSize(t.height, t.width);
cc.view.setDesignResolutionSize(this.sizeLanscape.width, this.sizeLanscape.height, cc.ResolutionPolicy.FIXED_HEIGHT);
cc.Canvas.instance.designResolution = cc.size(this.sizeLanscape.width, this.sizeLanscape.height);
}
};
e.prototype.callbackV = function() {
if (cc.sys.os == cc.sys.OS_IOS) {
cc.view.setOrientation(cc.macro.ORIENTATION_PORTRAIT);
jsb.reflection.callStaticMethod("AppController", "setOrientation:", "V");
var t = cc.view.getFrameSize();
BGUI.ZLog.log("màn hình dọc ios ========= " + this.sizePortrait.width + "   " + this.sizePortrait.height);
cc.view.setOrientation(cc.macro.ORIENTATION_PORTRAIT);
t.width > t.height && cc.view.setFrameSize(t.height, t.width);
cc.view.setDesignResolutionSize(this.sizePortrait.width, this.sizePortrait.height, cc.ResolutionPolicy.FIXED_WIDTH);
cc.Canvas.instance.designResolution = cc.size(this.sizePortrait.width, this.sizePortrait.height);
window.jsb && window.dispatchEvent(new cc.Event.EventCustom("resize", !0));
}
};
e.prototype.callbackAndroidVerticle = function(t) {
void 0 === t && (t = null);
jsb.reflection.callStaticMethod("org/cocos2dx/javascript/AppActivity", "setOrientation", "(Ljava/lang/String;)V", "V");
cc.view.setOrientation(cc.macro.ORIENTATION_PORTRAIT);
cc.view.setDesignResolutionSize(this.sizePortrait.width, this.sizePortrait.height, cc.ResolutionPolicy.FIXED_WIDTH);
};
e.prototype.callbackAndroidHorital = function(t) {
void 0 === t && (t = null);
jsb.reflection.callStaticMethod("org/cocos2dx/javascript/AppActivity", "setOrientation", "(Ljava/lang/String;)V", "H");
cc.view.setOrientation(cc.macro.ORIENTATION_LANDSCAPE);
cc.view.setDesignResolutionSize(this.sizeLanscape.width, this.sizeLanscape.height, cc.ResolutionPolicy.FIXED_HEIGHT);
};
i([ s ], e.prototype, "isVerticle", void 0);
i([ s({
visible: function() {
return this.isVerticle;
}
}) ], e.prototype, "sizePortrait", void 0);
i([ s({
visible: function() {
return !this.isVerticle;
}
}) ], e.prototype, "sizeLanscape", void 0);
return i([ a ], e);
}(cc.Component);
o.default = p;
cc._RF.pop();
}, {} ]
}, {}, [ "BhvShake", "BhvSine", "AutoDownloadTX", "IconBundleChat", "IconBundleLobby", "IconBundleMiniBauCua", "IconBundleMiniLongHo", "IconLobby", "BGUI.d", "LabelFontSet", "LabelLocalized", "LanguageMgr", "SpineAnimationSet", "SpineLocalized", "SpriteFrameSet", "SpriteLocalized", "cam", "en", "mm", "tl", "vn", "polyglot", "GameCoreManager", "BundleDownLoad", "CommonAssetDefined", "DropDown", "DropDownItem", "DropDownOptionData", "LoginFeature", "PrefabEDefined", "UIAutoLayout", "UIButtonCommon", "UIDragDrop", "UIDraggable", "UIJoystick", "UIPersitsNode", "UIPopup", "UIPopupCommon", "UIScreen", "UIScrollBar", "UIScrollContent", "UIScrollView", "UITabbarController", "UITabbarItem", "UITableCell", "UITableView", "UITextManager", "UITooltipHandler", "UITooltipListener", "UITooltipManager", "UITooltipMessage", "UITouchHandler", "UIWaitingLayout", "UIWindow", "HotUpdateFirstGame", "DemoClearCacheCtrl", "DemoFrameWork", "DemoListFramework", "zSetOrientation" ]);